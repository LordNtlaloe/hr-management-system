"use client";
import React, { useEffect, useState } from "react";
import Badge from "../ui/badge/Badge";
import { ArrowDownIcon, ArrowUpIcon, BoxIcon, GroupIcon, UserCheckIcon, UserXIcon, CalendarIcon } from "lucide-react";
import { getEmployeeStatusCounts } from "@/actions/leaves.actions";

interface EmployeeStatusCounts {
  active: number;
  suspended: number;
  onLeave: number;
  total: number;
}

export const EmployeeMetrics = () => {
  const [counts, setCounts] = useState<EmployeeStatusCounts | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const data = await getEmployeeStatusCounts();
        if ('error' in data) {
          throw new Error(data.error);
        }
        setCounts(data);
      } catch (error) {
        console.error(error);
        setError(error instanceof Error ? error.message : 'Failed to fetch employee data');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 md:gap-6">
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6 animate-pulse"
          >
            <div className="h-12 w-12 bg-gray-100 rounded-xl dark:bg-gray-800" />
            <div className="mt-5 space-y-3">
              <div className="h-4 w-1/2 bg-gray-100 rounded dark:bg-gray-800" />
              <div className="h-6 w-1/3 bg-gray-100 rounded dark:bg-gray-800" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <p className="text-red-500">{error}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 md:gap-6">
      {/* Total Employees */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-center justify-center w-12 h-12 bg-gray-100 rounded-xl dark:bg-gray-800">
          <GroupIcon className="text-gray-800 size-6 dark:text-white/90" />
        </div>
        <div className="flex items-end justify-between mt-5">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              Total Employees
            </span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {counts?.total ?? 0}
            </h4>
          </div>
        </div>
      </div>

      {/* Active Employees */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-center justify-center w-12 h-12 bg-gray-100 rounded-xl dark:bg-gray-800">
          <UserCheckIcon className="text-gray-800 size-6 dark:text-white/90" />
        </div>
        <div className="flex items-end justify-between mt-5">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              Active Employees
            </span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {counts?.active ?? 0}
            </h4>
          </div>
          <Badge color="success">
            <ArrowUpIcon />
            {counts ? `${Math.round((counts.active / counts.total) * 100)}%` : '0%'}
          </Badge>
        </div>
      </div>

      {/* On Leave */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-center justify-center w-12 h-12 bg-gray-100 rounded-xl dark:bg-gray-800">
          <CalendarIcon className="text-gray-800 size-6 dark:text-white/90" />
        </div>
        <div className="flex items-end justify-between mt-5">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              On Leave
            </span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {counts?.onLeave ?? 0}
            </h4>
          </div>
          <Badge color="warning">
            <ArrowUpIcon />
            {counts ? `${Math.round((counts.onLeave / counts.total) * 100)}%` : '0%'}
          </Badge>
        </div>
      </div>

      {/* Suspended (optional 4th metric) */}
      {/* <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-center justify-center w-12 h-12 bg-gray-100 rounded-xl dark:bg-gray-800">
          <UserXIcon className="text-gray-800 size-6 dark:text-white/90" />
        </div>
        <div className="flex items-end justify-between mt-5">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              Suspended
            </span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {counts?.suspended ?? 0}
            </h4>
          </div>
          <Badge color="error">
            <ArrowDownIcon />
            {counts ? `${Math.round((counts.suspended / counts.total) * 100)}%` : '0%'}
          </Badge>
        </div>
      </div> */}
    </div>
  );
};