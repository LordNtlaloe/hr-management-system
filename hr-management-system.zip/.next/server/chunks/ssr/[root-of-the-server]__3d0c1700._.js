module.exports = {

"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f138c36de97dc6fb19b8341028a901e1f88da6087":"updateDocument","7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2":"getAllEmployeeDocuments","7f6ccbe79e36dcf5799d740bcdb8e39a6952514711":"deleteEmployeeDocument","7f89613ad158d989b8b34393ea23a9dacd266237e4":"deleteDocument","7fa3b7c7610072e47d330dc05cfb9884ad2b97a838":"getDocumentsByEmployee","7fd62967b35c4ecdc6f7b46cfb15514ee305e80f90":"getDocumentById","7feaacf192c8bd439d8b052515ddc7dfc51656232c":"downloadEmployeeDocument","7feb75fa17bd2c20f93ea61edafde4c5e91095ab45":"getDocumentsByType","7ff3d1d5c4352e1e5523451c60c00293a73b2cbb2f":"uploadEmployeeDocument"},"",""] */ __turbopack_context__.s({
    "deleteDocument": (()=>deleteDocument),
    "deleteEmployeeDocument": (()=>deleteEmployeeDocument),
    "downloadEmployeeDocument": (()=>downloadEmployeeDocument),
    "getAllEmployeeDocuments": (()=>getAllEmployeeDocuments),
    "getDocumentById": (()=>getDocumentById),
    "getDocumentsByEmployee": (()=>getDocumentsByEmployee),
    "getDocumentsByType": (()=>getDocumentsByType),
    "updateDocument": (()=>updateDocument),
    "uploadEmployeeDocument": (()=>uploadEmployeeDocument)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/schemas/index.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
let dbConnection;
let database;
const init = async ()=>{
    try {
        const connection = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["connectToDB"])();
        dbConnection = connection;
        database = await dbConnection?.db("hr_management_db");
    } catch (error) {
        console.error("Database connection failed:", error);
        throw error;
    }
};
// File storage directory (adjust as needed)
const DOCUMENTS_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'public', 'employee-documents');
// Ensure directory exists
async function ensureDocumentsDir() {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].mkdir(DOCUMENTS_DIR, {
            recursive: true
        });
    } catch (error) {
        console.error("Error creating documents directory:", error);
        throw error;
    }
}
const uploadEmployeeDocument = async (formData)=>{
    if (!dbConnection) await init();
    await ensureDocumentsDir();
    try {
        const parsedData = __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["FileUploadSchema"].parse({
            employee_id: formData.get('employee_id'),
            document_type: formData.get('document_type'),
            description: formData.get('description'),
            files: formData.getAll('files')
        });
        const collection = await database?.collection("employee_documents");
        const results = [];
        for (const file of parsedData.files){
            const fileBuffer = await file.arrayBuffer();
            const uniqueFilename = `${Date.now()}-${file.name.replace(/\s+/g, '-')}`;
            const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(DOCUMENTS_DIR, uniqueFilename);
            await __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["promises"].writeFile(filePath, Buffer.from(fileBuffer));
            const documentData = {
                employee_id: parsedData.employee_id,
                document_type: parsedData.document_type,
                document_name: file.name,
                original_filename: file.name,
                file_path: `/employee-documents/${uniqueFilename}`,
                file_size: file.size,
                mime_type: file.type,
                uploaded_at: new Date(),
                uploaded_by: null,
                description: parsedData.description,
                is_active: true
            };
            const result = await collection.insertOne(documentData);
            results.push({
                insertedId: result.insertedId.toString(),
                document_name: file.name
            });
        }
        return {
            success: true,
            results
        };
    } catch (error) {
        console.error("Error uploading document:", error.message);
        return {
            error: error.message
        };
    }
};
const getDocumentById = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const document = await collection.findOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        });
        return document ? {
            ...document,
            _id: document._id.toString()
        } : null;
    } catch (error) {
        console.error("Error fetching document:", error.message);
        return {
            error: error.message
        };
    }
};
const getDocumentsByEmployee = async (employeeId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const documents = await collection.find({
            employee_id: employeeId,
            is_active: true
        }).toArray();
        return documents.map((doc)=>({
                ...doc,
                _id: doc._id.toString()
            }));
    } catch (error) {
        console.error("Error fetching employee documents:", error.message);
        return {
            error: error.message
        };
    }
};
const updateDocument = async (id, updateData)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                ...updateData,
                updated_at: new Date()
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error updating document:", error.message);
        return {
            error: error.message
        };
    }
};
const deleteDocument = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        // Soft delete (recommended)
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                is_active: false,
                deleted_at: new Date()
            }
        });
        // Alternative: Hard delete with file removal
        /*
        const document = await collection.findOne({ _id: new ObjectId(id) });
        if (document) {
            const filePath = path.join(process.cwd(), 'public', document.file_path);
            try {
                await fs.unlink(filePath);
            } catch (fileError) {
                console.warn("Could not delete file:", fileError);
            }
        }
        const result = await collection.deleteOne({ _id: new ObjectId(id) });
        */ return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error deleting document:", error.message);
        return {
            error: error.message
        };
    }
};
const getDocumentsByType = async (employeeId, documentType)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const documents = await collection.find({
            employee_id: employeeId,
            document_type: documentType,
            is_active: true
        }).toArray();
        return documents.map((doc)=>({
                ...doc,
                _id: doc._id.toString()
            }));
    } catch (error) {
        console.error("Error fetching documents by type:", error.message);
        return {
            error: error.message
        };
    }
};
const getAllEmployeeDocuments = async (employeeId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const documents = await collection.find({
            employee_id: employeeId,
            is_active: true
        }).sort({
            uploaded_at: -1
        }).toArray();
        // Convert MongoDB documents to our schema format
        const parsedDocuments = documents.map((doc)=>({
                ...doc,
                _id: doc._id.toString(),
                uploaded_at: doc.uploaded_at.toISOString()
            }));
        return {
            success: true,
            data: parsedDocuments
        };
    } catch (error) {
        console.error("Error fetching employee documents:", error.message);
        return {
            success: false,
            error: error.message
        };
    }
};
const downloadEmployeeDocument = async (documentId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const document = await collection.findOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](documentId),
            is_active: true
        });
        if (!document) {
            return {
                success: false,
                error: "Document not found"
            };
        }
        // In a real implementation, you would:
        // 1. For local files: Generate a signed URL or serve the file
        // 2. For cloud storage: Generate a download URL
        // Here's a simplified version:
        return {
            success: true,
            downloadUrl: document.file_path,
            filename: document.original_filename
        };
    } catch (error) {
        console.error("Error preparing document download:", error.message);
        return {
            success: false,
            error: error.message
        };
    }
};
const deleteEmployeeDocument = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        // Soft delete (recommended)
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                is_active: false,
                deleted_at: new Date()
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error deleting document:", error.message);
        return {
            error: error.message
        };
    }
};
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    uploadEmployeeDocument,
    getDocumentById,
    getDocumentsByEmployee,
    updateDocument,
    deleteDocument,
    getDocumentsByType,
    getAllEmployeeDocuments,
    downloadEmployeeDocument,
    deleteEmployeeDocument
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(uploadEmployeeDocument, "7ff3d1d5c4352e1e5523451c60c00293a73b2cbb2f", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getDocumentById, "7fd62967b35c4ecdc6f7b46cfb15514ee305e80f90", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getDocumentsByEmployee, "7fa3b7c7610072e47d330dc05cfb9884ad2b97a838", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(updateDocument, "7f138c36de97dc6fb19b8341028a901e1f88da6087", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deleteDocument, "7f89613ad158d989b8b34393ea23a9dacd266237e4", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getDocumentsByType, "7feb75fa17bd2c20f93ea61edafde4c5e91095ab45", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getAllEmployeeDocuments, "7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(downloadEmployeeDocument, "7feaacf192c8bd439d8b052515ddc7dfc51656232c", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deleteEmployeeDocument, "7f6ccbe79e36dcf5799d740bcdb8e39a6952514711", null);
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)");
;
;
;
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <exports>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAllEmployeeDocuments"]),
    "7f6ccbe79e36dcf5799d740bcdb8e39a6952514711": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["deleteEmployeeDocument"]),
    "7feaacf192c8bd439d8b052515ddc7dfc51656232c": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["downloadEmployeeDocument"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2"]),
    "7f6ccbe79e36dcf5799d740bcdb8e39a6952514711": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f6ccbe79e36dcf5799d740bcdb8e39a6952514711"]),
    "7feaacf192c8bd439d8b052515ddc7dfc51656232c": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7feaacf192c8bd439d8b052515ddc7dfc51656232c"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <module evaluation>');
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <exports>');
}}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/(admin)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/(admin)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/(admin)/employee-documents/page.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "EmployeeDocumentsList": (()=>EmployeeDocumentsList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const EmployeeDocumentsList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call EmployeeDocumentsList() from the server but EmployeeDocumentsList is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/(protected)/(admin)/employee-documents/page.tsx <module evaluation>", "EmployeeDocumentsList");
}}),
"[project]/app/(protected)/(admin)/employee-documents/page.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "EmployeeDocumentsList": (()=>EmployeeDocumentsList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const EmployeeDocumentsList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call EmployeeDocumentsList() from the server but EmployeeDocumentsList is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/(protected)/(admin)/employee-documents/page.tsx", "EmployeeDocumentsList");
}}),
"[project]/app/(protected)/(admin)/employee-documents/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/app/(protected)/(admin)/employee-documents/page.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/app/(protected)/(admin)/employee-documents/page.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/app/(protected)/(admin)/employee-documents/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/(admin)/employee-documents/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__3d0c1700._.js.map