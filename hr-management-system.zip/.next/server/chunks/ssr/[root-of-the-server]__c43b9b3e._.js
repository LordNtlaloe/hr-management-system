module.exports = {

"[externals]/querystring [external] (querystring, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("querystring", () => require("querystring"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f1ca09f7bec0fd2ec2ec172599bdeecf539f371aa":"getDocumentsByEmployeeId","7f2185529f04a4ef46cf01097ddb1a1b401002056c":"getActiveDocumentTypesForEmployee","7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2":"getAllEmployeeDocuments","7f58cfb79edce26b57876bab68bf741d40f865b1fc":"updateEmployeeDocument","7f6ccbe79e36dcf5799d740bcdb8e39a6952514711":"deleteEmployeeDocument","7f6f8cff0e1265ee5f173fa28997adb3a311698f5e":"getEmployeeDocumentById","7f85a8e0f2b366aed974a5625d2020b466c5cd3cad":"getAllDocuments","7f881dc47934c51898620da1a0100127ce3477d7a6":"getEmployeeDocuments","7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2":"createEmployeeDocument","7fd13ee0aface220a5d221985dc6d8ec0113f84fc0":"validateEmployeeDocuments","7feb75fa17bd2c20f93ea61edafde4c5e91095ab45":"getDocumentsByType"},"",""] */ __turbopack_context__.s({
    "createEmployeeDocument": (()=>createEmployeeDocument),
    "deleteEmployeeDocument": (()=>deleteEmployeeDocument),
    "getActiveDocumentTypesForEmployee": (()=>getActiveDocumentTypesForEmployee),
    "getAllDocuments": (()=>getAllDocuments),
    "getAllEmployeeDocuments": (()=>getAllEmployeeDocuments),
    "getDocumentsByEmployeeId": (()=>getDocumentsByEmployeeId),
    "getDocumentsByType": (()=>getDocumentsByType),
    "getEmployeeDocumentById": (()=>getEmployeeDocumentById),
    "getEmployeeDocuments": (()=>getEmployeeDocuments),
    "updateEmployeeDocument": (()=>updateEmployeeDocument),
    "validateEmployeeDocuments": (()=>validateEmployeeDocuments)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cloudinary$2f$cloudinary$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/cloudinary/cloudinary.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/schemas/index.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
;
;
// Configure Cloudinary
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cloudinary$2f$cloudinary$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["v2"].config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_SECRET_KEY,
    secure: true
});
let dbConnection;
let database;
const init = async ()=>{
    try {
        const connection = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["connectToDB"])();
        dbConnection = connection;
        database = await dbConnection?.db("hr_management_db");
    } catch (error) {
        console.error("Database connection failed:", error);
        throw error;
    }
};
async function uploadToCloudinary(file) {
    try {
        const arrayBuffer = await file.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        return new Promise((resolve, reject)=>{
            const uploadStream = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cloudinary$2f$cloudinary$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["v2"].uploader.upload_stream({
                folder: 'employee-documents',
                resource_type: 'auto',
                allowed_formats: [
                    'jpg',
                    'png',
                    'webp',
                    'pdf',
                    'doc',
                    'docx'
                ],
                transformation: [
                    {
                        width: 1200,
                        height: 1200,
                        crop: "limit"
                    },
                    {
                        quality: "auto"
                    }
                ]
            }, (error, result)=>{
                if (error || !result) {
                    console.error('Cloudinary upload error:', error);
                    reject(error || new Error('Upload failed'));
                    return;
                }
                resolve(result.secure_url);
            });
            uploadStream.end(buffer);
        });
    } catch (error) {
        console.error('Error processing file upload:', error);
        return null;
    }
}
const createEmployeeDocument = async (formData)=>{
    if (!dbConnection) await init();
    try {
        // Extract form data
        const employee_id = formData.get('employee_id');
        const national_id_number = formData.get('national_id');
        if (!employee_id) {
            return {
                error: "Employee ID is required"
            };
        }
        if (!national_id_number) {
            return {
                error: "National ID number is required"
            };
        }
        // Handle file uploads
        const nationalIdFile = formData.get('national_id_file');
        const passportPhotoFile = formData.get('passport_photo_file');
        const academicCertificates = formData.getAll('academic_certificates_files');
        const policeClearanceFile = formData.get('police_clearance_file');
        const medicalCertificateFile = formData.get('medical_certificate_file');
        const driverLicenseFile = formData.get('driver_license_file');
        // Validate required files
        if (!passportPhotoFile || passportPhotoFile.size === 0) {
            return {
                error: "Passport photo is required"
            };
        }
        if (!academicCertificates.length || academicCertificates.every((f)=>f.size === 0)) {
            return {
                error: "At least one academic certificate is required"
            };
        }
        // Upload files to Cloudinary
        const uploadPromises = [];
        const fileTypes = [];
        // National ID (optional)
        if (nationalIdFile && nationalIdFile.size > 0) {
            uploadPromises.push(uploadToCloudinary(nationalIdFile));
            fileTypes.push('national_id');
        }
        // Passport Photo (required)
        uploadPromises.push(uploadToCloudinary(passportPhotoFile));
        fileTypes.push('passport_photo');
        // Academic Certificates (required, multiple)
        const validAcademicCerts = academicCertificates.filter((f)=>f.size > 0);
        for (const cert of validAcademicCerts){
            uploadPromises.push(uploadToCloudinary(cert));
            fileTypes.push('academic_certificate');
        }
        // Optional documents
        if (policeClearanceFile && policeClearanceFile.size > 0) {
            uploadPromises.push(uploadToCloudinary(policeClearanceFile));
            fileTypes.push('police_clearance');
        }
        if (medicalCertificateFile && medicalCertificateFile.size > 0) {
            uploadPromises.push(uploadToCloudinary(medicalCertificateFile));
            fileTypes.push('medical_certificate');
        }
        if (driverLicenseFile && driverLicenseFile.size > 0) {
            uploadPromises.push(uploadToCloudinary(driverLicenseFile));
            fileTypes.push('driver_license');
        }
        // Wait for all uploads to complete
        const uploadResults = await Promise.all(uploadPromises);
        // Process upload results
        let national_id_url = "";
        let passport_photo_url = "";
        const academic_certificates_urls = [];
        let police_clearance_url = "";
        let medical_certificate_url = "";
        let driver_license_url = "";
        let resultIndex = 0;
        for(let i = 0; i < fileTypes.length; i++){
            const result = uploadResults[resultIndex];
            if (!result) {
                return {
                    error: `Failed to upload ${fileTypes[i]} file`
                };
            }
            switch(fileTypes[i]){
                case 'national_id':
                    national_id_url = result;
                    break;
                case 'passport_photo':
                    passport_photo_url = result;
                    break;
                case 'academic_certificate':
                    academic_certificates_urls.push(result);
                    break;
                case 'police_clearance':
                    police_clearance_url = result;
                    break;
                case 'medical_certificate':
                    medical_certificate_url = result;
                    break;
                case 'driver_license':
                    driver_license_url = result;
                    break;
            }
            resultIndex++;
        }
        // Prepare document data
        const documentData = {
            employee_id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employee_id),
            national_id: national_id_number,
            national_id_document: national_id_url || "",
            passport_photo: passport_photo_url,
            academic_certificates: academic_certificates_urls,
            police_clearance: police_clearance_url || "",
            medical_certificate: medical_certificate_url || "",
            driver_license: driver_license_url || "",
            uploaded_at: new Date(),
            is_active: true
        };
        // Validate the final data structure
        const validated = __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["EmployeeDocumentSchema"].parse({
            employee_id: employee_id,
            national_id: national_id_number,
            passport_photo: passport_photo_url,
            academic_certificates: academic_certificates_urls,
            police_clearance: police_clearance_url,
            medical_certificate: medical_certificate_url,
            driver_license: driver_license_url
        });
        // Save to database
        const collection = await database.collection("employee_documents");
        // Check if documents already exist for this employee
        const existingDocument = await collection.findOne({
            employee_id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employee_id),
            is_active: true
        });
        let result;
        if (existingDocument) {
            // Update existing document
            result = await collection.updateOne({
                employee_id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employee_id),
                is_active: true
            }, {
                $set: {
                    ...documentData,
                    updated_at: new Date()
                }
            });
            return {
                success: true,
                message: "Employee documents updated successfully",
                documentId: existingDocument._id.toString()
            };
        } else {
            // Create new document record
            result = await collection.insertOne(documentData);
            return {
                insertedId: result.insertedId.toString(),
                success: true,
                message: "Employee documents uploaded successfully"
            };
        }
    } catch (error) {
        console.error("Error saving document:", error);
        // Handle validation errors
        if (error.name === 'ZodError') {
            const validationErrors = error.errors.map((err)=>`${err.path.join('.')}: ${err.message}`).join(', ');
            return {
                error: `Validation error: ${validationErrors}`,
                details: ("TURBOPACK compile-time truthy", 1) ? error.errors : ("TURBOPACK unreachable", undefined)
            };
        }
        return {
            error: error.message || "An unexpected error occurred",
            details: ("TURBOPACK compile-time truthy", 1) ? error.stack : ("TURBOPACK unreachable", undefined)
        };
    }
};
const getEmployeeDocumentById = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const document = await collection.findOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        });
        return document ? {
            ...document,
            _id: document._id.toString(),
            employee_id: document.employee_id.toString()
        } : null;
    } catch (error) {
        console.error("Error fetching employee document:", error.message);
        return {
            error: error.message
        };
    }
};
const getEmployeeDocuments = async (employeeId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const documents = await collection.find({
            employee_id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeId),
            is_active: true
        }).toArray();
        return documents.map((doc)=>({
                ...doc,
                _id: doc._id.toString(),
                employee_id: doc.employee_id.toString()
            }));
    } catch (error) {
        console.error("Error fetching employee documents:", error.message);
        return {
            error: error.message
        };
    }
};
const updateEmployeeDocument = async (id, updateData)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                ...updateData,
                updated_at: new Date()
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error updating employee document:", error.message);
        return {
            error: error.message
        };
    }
};
const deleteEmployeeDocument = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                is_active: false,
                deleted_at: new Date()
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error deleting employee document:", error.message);
        return {
            error: error.message
        };
    }
};
const getAllEmployeeDocuments = async (employeeId, includeInactive = false)=>{
    if (!dbConnection) await init();
    try {
        const documentsCollection = await database?.collection("employee_documents");
        const employeesCollection = await database?.collection("employees");
        if (!database || !documentsCollection || !employeesCollection) {
            throw new Error("Failed to connect to database collections");
        }
        // Validate employeeId format
        if (!__TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"].isValid(employeeId)) {
            throw new Error("Invalid employee ID format");
        }
        const documents = await documentsCollection.aggregate([
            {
                $match: {
                    employee_id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeId),
                    ...!includeInactive && {
                        is_active: {
                            $ne: false
                        }
                    }
                }
            },
            {
                $lookup: {
                    from: "employees",
                    localField: "employee_id",
                    foreignField: "_id",
                    as: "employee"
                }
            },
            {
                $unwind: {
                    path: "$employee",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $addFields: {
                    employee_name: {
                        $cond: {
                            if: "$employee",
                            then: {
                                $concat: [
                                    "$employee.first_name",
                                    " ",
                                    "$employee.last_name"
                                ]
                            },
                            else: "Unknown Employee"
                        }
                    },
                    // Ensure dates are properly formatted
                    created_at: {
                        $cond: {
                            if: {
                                $ne: [
                                    "$created_at",
                                    null
                                ]
                            },
                            then: "$created_at",
                            else: new Date()
                        }
                    },
                    updated_at: {
                        $cond: {
                            if: {
                                $ne: [
                                    "$updated_at",
                                    null
                                ]
                            },
                            then: "$updated_at",
                            else: null
                        }
                    }
                }
            }
        ]).toArray();
        // Convert to plain objects with proper serialization
        return documents.map((doc)=>{
            const convertedDoc = {
                ...doc,
                _id: doc._id?.toString() || '',
                employee_id: doc.employee_id?.toString() || employeeId,
                // Convert dates to ISO strings
                created_at: doc.created_at?.toISOString?.() || new Date().toISOString(),
                updated_at: doc.updated_at?.toISOString?.() || null,
                // Handle all document fields
                national_id: doc.national_id || '',
                passport_photo: doc.passport_photo || null,
                academic_certificates: doc.academic_certificates || [],
                police_clearance: doc.police_clearance || null,
                medical_certificate: doc.medical_certificate || null,
                driver_license: doc.driver_license || null,
                is_active: doc.is_active ?? true,
                // Ensure employee_name is included
                employee_name: doc.employee_name || 'Unknown Employee'
            };
            // Remove temporary fields
            delete convertedDoc.employee;
            return convertedDoc;
        });
    } catch (error) {
        console.error("Error fetching employee documents:", error.message);
        return {
            error: error.message,
            statusCode: error instanceof Error && error.message.includes("Invalid") ? 400 : 500
        };
    }
};
const getDocumentsByType = async (employeeId, documentType, includeInactive = false)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const filter = {
            employee_id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeId),
            document_type: documentType
        };
        if (!includeInactive) {
            filter.is_active = {
                $ne: false
            };
        }
        const documents = await collection.find(filter).toArray();
        return documents.map((doc)=>({
                ...doc,
                _id: doc._id.toString(),
                employee_id: doc.employee_id.toString()
            }));
    } catch (error) {
        console.error("Error fetching documents by type:", error.message);
        return {
            error: error.message
        };
    }
};
const getDocumentsByEmployeeId = async (employeeId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const filter = {
            employee_id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeId)
        };
        const documents = await collection.find(filter).toArray();
        return documents.map((doc)=>({
                ...doc,
                _id: doc._id.toString(),
                employee_id: doc.employee_id.toString()
            }));
    } catch (error) {
        console.error("Error fetching documents by type:", error.message);
        return {
            error: error.message
        };
    }
};
const getActiveDocumentTypesForEmployee = async (employeeId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const result = await collection.aggregate([
            {
                $match: {
                    employee_id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeId),
                    is_active: true
                }
            },
            {
                $group: {
                    _id: "$document_type"
                }
            }
        ]).toArray();
        return result.map((item)=>item._id);
    } catch (error) {
        console.error("Error fetching active document types:", error.message);
        return {
            error: error.message
        };
    }
};
const validateEmployeeDocuments = async (employeeId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const documents = await collection.findOne({
            employee_id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeId),
            is_active: true
        });
        if (!documents) {
            return {
                isValid: false,
                missing: [
                    'passport_photo',
                    'academic_certificates'
                ],
                message: "No documents found for this employee"
            };
        }
        const missing = [];
        if (!documents.passport_photo) missing.push('passport_photo');
        if (!documents.academic_certificates || documents.academic_certificates.length === 0) {
            missing.push('academic_certificates');
        }
        return {
            isValid: missing.length === 0,
            missing,
            message: missing.length === 0 ? "All required documents are present" : `Missing: ${missing.join(', ')}`
        };
    } catch (error) {
        console.error("Error validating employee documents:", error.message);
        return {
            error: error.message
        };
    }
};
const getAllDocuments = async ()=>{
    if (!dbConnection) await init();
    try {
        const documentsCollection = await database?.collection("employee_documents");
        const employeesCollection = await database?.collection("employees");
        if (!database || !documentsCollection || !employeesCollection) {
            return {
                error: "Failed to connect to database"
            };
        }
        const documents = await documentsCollection.aggregate([
            {
                $lookup: {
                    from: "employees",
                    localField: "employee_id",
                    foreignField: "_id",
                    as: "employee"
                }
            },
            {
                $unwind: {
                    path: "$employee",
                    preserveNullAndEmptyArrays: true // Handle cases where employee might not exist
                }
            },
            {
                $addFields: {
                    employee_name: {
                        $cond: {
                            if: "$employee",
                            then: {
                                $concat: [
                                    "$employee.first_name",
                                    " ",
                                    "$employee.last_name"
                                ]
                            },
                            else: "Unknown Employee"
                        }
                    }
                }
            }
        ]).toArray();
        // Convert MongoDB documents to plain objects with proper null checks
        return documents.map((doc)=>{
            const convertedDoc = {
                ...doc,
                _id: doc._id?.toString() || '',
                employee_id: doc.employee_id?.toString() || '',
                employee_name: doc.employee_name || 'Unknown Employee',
                created_at: doc.created_at?.toISOString() || new Date().toISOString(),
                updated_at: doc.updated_at?.toISOString() || null,
                // Handle all other fields with proper defaults
                national_id: doc.national_id || '',
                passport_photo: doc.passport_photo || null,
                academic_certificates: doc.academic_certificates || [],
                police_clearance: doc.police_clearance || null,
                medical_certificate: doc.medical_certificate || null,
                driver_license: doc.driver_license || null
            };
            // Remove the nested employee object if it exists
            if (convertedDoc.employee) {
                delete convertedDoc.employee;
            }
            return convertedDoc;
        });
    } catch (error) {
        console.error("Error fetching documents:", error.message);
        return {
            error: error.message
        };
    }
};
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    createEmployeeDocument,
    getEmployeeDocumentById,
    getEmployeeDocuments,
    updateEmployeeDocument,
    deleteEmployeeDocument,
    getAllEmployeeDocuments,
    getDocumentsByType,
    getDocumentsByEmployeeId,
    getActiveDocumentTypesForEmployee,
    validateEmployeeDocuments,
    getAllDocuments
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createEmployeeDocument, "7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeeDocumentById, "7f6f8cff0e1265ee5f173fa28997adb3a311698f5e", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeeDocuments, "7f881dc47934c51898620da1a0100127ce3477d7a6", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(updateEmployeeDocument, "7f58cfb79edce26b57876bab68bf741d40f865b1fc", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deleteEmployeeDocument, "7f6ccbe79e36dcf5799d740bcdb8e39a6952514711", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getAllEmployeeDocuments, "7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getDocumentsByType, "7feb75fa17bd2c20f93ea61edafde4c5e91095ab45", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getDocumentsByEmployeeId, "7f1ca09f7bec0fd2ec2ec172599bdeecf539f371aa", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getActiveDocumentTypesForEmployee, "7f2185529f04a4ef46cf01097ddb1a1b401002056c", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(validateEmployeeDocuments, "7fd13ee0aface220a5d221985dc6d8ec0113f84fc0", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getAllDocuments, "7f85a8e0f2b366aed974a5625d2020b466c5cd3cad", null);
}}),
"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f07033d9c73c17a63f43a9cfa5012cb6cfef258c2":"updateEmployee","7f216b9e67a84dc38e0c070d8ac699330adbc59d0d":"getEmployeeById","7f4b7cc6a48ce840cd9bc8a27ccaed90acf597d14b":"deleteEmployee","7f5fa9459441e3aae9593059298f1c5b5414b1e9f7":"getAllEmployees","7fd73fd02f8b69452d3050b76c08df4aa935d6c24d":"getEmployeesByDepartment","7fe73a856bb5a41421c36b83c716fffe022a846e45":"createEmployee"},"",""] */ __turbopack_context__.s({
    "createEmployee": (()=>createEmployee),
    "deleteEmployee": (()=>deleteEmployee),
    "getAllEmployees": (()=>getAllEmployees),
    "getEmployeeById": (()=>getEmployeeById),
    "getEmployeesByDepartment": (()=>getEmployeesByDepartment),
    "updateEmployee": (()=>updateEmployee)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
let dbConnection;
let database;
const init = async ()=>{
    try {
        const connection = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["connectToDB"])();
        dbConnection = connection;
        database = await dbConnection?.db("hr_management_db");
    } catch (error) {
        console.error("Database connection failed:", error);
        throw error;
    }
};
const createEmployee = async (employeeData)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const employee = {
            ...employeeData,
            createdAt: new Date(),
            updatedAt: new Date(),
            isActive: true
        };
        const result = await collection.insertOne(employee);
        return {
            insertedId: result.insertedId.toString(),
            success: true
        };
    } catch (error) {
        console.error("Error creating employee:", error.message);
        return {
            error: error.message
        };
    }
};
const getEmployeeById = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const employee = await collection.findOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        });
        return employee ? {
            ...employee,
            _id: employee._id.toString()
        } : null;
    } catch (error) {
        console.error("Error fetching employee:", error.message);
        return {
            error: error.message
        };
    }
};
const updateEmployee = async (id, updateData)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                ...updateData,
                updatedAt: new Date()
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error updating employee:", error.message);
        return {
            error: error.message
        };
    }
};
const deleteEmployee = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                isActive: false,
                deletedAt: new Date()
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error deleting employee:", error.message);
        return {
            error: error.message
        };
    }
};
const getAllEmployees = async (includeInactive = false)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const positionCollection = await database?.collection("positions");
        const departmentCollection = await database?.collection("departments");
        const filter = includeInactive ? {} : {
            isActive: {
                $ne: false
            }
        };
        const employees = await collection.find(filter).toArray();
        // Enhance employees with department and position names
        const enhancedEmployees = await Promise.all(employees.map(async (employee)=>{
            // Try both field name variations to handle inconsistencies
            const positionId = employee.positionId || employee.position_id;
            const departmentId = employee.departmentId || employee.department_id;
            const position = positionId ? await positionCollection.findOne({
                _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](positionId)
            }) : null;
            const department = departmentId ? await departmentCollection.findOne({
                _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](departmentId)
            }) : null;
            return {
                ...employee,
                _id: employee._id.toString(),
                // Ensure these field names match what your columns expect
                position_title: position?.position_title || "Unknown",
                department_name: department?.department_name || "Unknown",
                manager_name: employee.managerId ? await getEmployeeName(employee.managerId) : null,
                // Include the original IDs for reference
                positionId: positionId,
                departmentId: departmentId
            };
        }));
        return enhancedEmployees;
    } catch (error) {
        console.error("Error fetching employees:", error.message);
        return {
            error: error.message
        };
    }
};
async function getEmployeeName(employeeId) {
    const collection = await database?.collection("employees");
    const employee = await collection.findOne({
        _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeId)
    });
    return employee ? `${employee.firstName} ${employee.lastName}` : null;
}
const getEmployeesByDepartment = async (departmentId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const employees = await collection.find({
            departmentId: departmentId,
            isActive: {
                $ne: false
            }
        }).toArray();
        return employees.map((employee)=>({
                ...employee,
                _id: employee._id.toString()
            }));
    } catch (error) {
        console.error("Error fetching department employees:", error.message);
        return {
            error: error.message
        };
    }
};
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    createEmployee,
    getEmployeeById,
    updateEmployee,
    deleteEmployee,
    getAllEmployees,
    getEmployeesByDepartment
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createEmployee, "7fe73a856bb5a41421c36b83c716fffe022a846e45", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeeById, "7f216b9e67a84dc38e0c070d8ac699330adbc59d0d", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(updateEmployee, "7f07033d9c73c17a63f43a9cfa5012cb6cfef258c2", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deleteEmployee, "7f4b7cc6a48ce840cd9bc8a27ccaed90acf597d14b", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getAllEmployees, "7f5fa9459441e3aae9593059298f1c5b5414b1e9f7", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeesByDepartment, "7fd73fd02f8b69452d3050b76c08df4aa935d6c24d", null);
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employees/[id]/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/user.actions.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE2 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/user.actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.actions.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employees/[id]/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/user.actions.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE2 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/user.actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employees/[id]/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/user.actions.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)", ACTIONS_MODULE2 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employees/[id]/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/user.actions.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE2 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <exports>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "7f5fa9459441e3aae9593059298f1c5b5414b1e9f7": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAllEmployees"]),
    "7f67f7faeb99bbdf4ef26746d2cc7d214370187606": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["updateUser"]),
    "7f7691714fe623c02252debd178011d416dbe1579a": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getUserByEmail"]),
    "7f78da17957c0c1a3fde38ccad47511e9f411fe76a": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getUserRoleById"]),
    "7f873a0eed57b9f073594d610c40b8f21c6eb0ae17": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAllUsers"]),
    "7f8dd073e0d11637f85e8a24e3eb6c38ef87f96414": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["searchUsers"]),
    "7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createEmployeeDocument"]),
    "7fc77473e3cde8e9134f67b833c83a5a010b27e58b": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["deleteUser"]),
    "7fc88f404b9c4de54cfb66e6063649b512730438dc": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createUser"]),
    "7fe55800feb036651ffa4950e0562b36bb544f921b": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getUserById"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/user.actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employees/[id]/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/user.actions.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)", ACTIONS_MODULE2 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employees/[id]/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/user.actions.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE2 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "7f5fa9459441e3aae9593059298f1c5b5414b1e9f7": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f5fa9459441e3aae9593059298f1c5b5414b1e9f7"]),
    "7f67f7faeb99bbdf4ef26746d2cc7d214370187606": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f67f7faeb99bbdf4ef26746d2cc7d214370187606"]),
    "7f7691714fe623c02252debd178011d416dbe1579a": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f7691714fe623c02252debd178011d416dbe1579a"]),
    "7f78da17957c0c1a3fde38ccad47511e9f411fe76a": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f78da17957c0c1a3fde38ccad47511e9f411fe76a"]),
    "7f873a0eed57b9f073594d610c40b8f21c6eb0ae17": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f873a0eed57b9f073594d610c40b8f21c6eb0ae17"]),
    "7f8dd073e0d11637f85e8a24e3eb6c38ef87f96414": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f8dd073e0d11637f85e8a24e3eb6c38ef87f96414"]),
    "7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2"]),
    "7fc77473e3cde8e9134f67b833c83a5a010b27e58b": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7fc77473e3cde8e9134f67b833c83a5a010b27e58b"]),
    "7fc88f404b9c4de54cfb66e6063649b512730438dc": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7fc88f404b9c4de54cfb66e6063649b512730438dc"]),
    "7fe55800feb036651ffa4950e0562b36bb544f921b": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7fe55800feb036651ffa4950e0562b36bb544f921b"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employees/[id]/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/user.actions.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)", ACTIONS_MODULE2 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <module evaluation>');
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$user$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE2__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employees/[id]/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/user.actions.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)", ACTIONS_MODULE2 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <exports>');
}}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/(admin)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/(admin)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx <module evaluation>", "default");
}}),
"[project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx", "default");
}}),
"[project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employees$2f5b$id$5d2f$employee$2d$documents$2f$create$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/(admin)/employees/[id]/employee-documents/create/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__c43b9b3e._.js.map