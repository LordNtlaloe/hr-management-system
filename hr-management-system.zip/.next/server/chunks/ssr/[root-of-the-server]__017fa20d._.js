module.exports = {

"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f2185529f04a4ef46cf01097ddb1a1b401002056c":"getActiveDocumentTypesForEmployee","7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2":"getAllEmployeeDocuments","7f58cfb79edce26b57876bab68bf741d40f865b1fc":"updateEmployeeDocument","7f6ccbe79e36dcf5799d740bcdb8e39a6952514711":"deleteEmployeeDocument","7f6f8cff0e1265ee5f173fa28997adb3a311698f5e":"getEmployeeDocumentById","7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2":"createEmployeeDocument","7feb75fa17bd2c20f93ea61edafde4c5e91095ab45":"getDocumentsByType"},"",""] */ __turbopack_context__.s({
    "createEmployeeDocument": (()=>createEmployeeDocument),
    "deleteEmployeeDocument": (()=>deleteEmployeeDocument),
    "getActiveDocumentTypesForEmployee": (()=>getActiveDocumentTypesForEmployee),
    "getAllEmployeeDocuments": (()=>getAllEmployeeDocuments),
    "getDocumentsByType": (()=>getDocumentsByType),
    "getEmployeeDocumentById": (()=>getEmployeeDocumentById),
    "updateEmployeeDocument": (()=>updateEmployeeDocument)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/schemas/index.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
let dbConnection;
let database;
const init = async ()=>{
    try {
        const connection = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["connectToDB"])();
        dbConnection = connection;
        database = await dbConnection?.db("hr_management_db");
    } catch (error) {
        console.error("Database connection failed:", error);
        throw error;
    }
};
async function uploadFile(file) {
    try {
        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);
        // Ensure uploads directory exists
        const uploadDir = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'public', 'uploads');
        await fs.promises.mkdir(uploadDir, {
            recursive: true
        });
        // Create unique filename
        const timestamp = Date.now();
        const ext = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].extname(file.name);
        const filename = `${timestamp}${ext}`;
        const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(uploadDir, filename);
        await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["writeFile"])(filePath, buffer);
        return {
            filePath: `/uploads/${filename}`,
            success: true
        };
    } catch (error) {
        console.error("File upload error:", error);
        return {
            filePath: "",
            success: false,
            error: "Failed to upload file"
        };
    }
}
const createEmployeeDocument = async (formData)=>{
    if (!dbConnection) await init();
    try {
        // Extract data from FormData
        const file = formData.get('file');
        const employee_id = formData.get('employee_id');
        const document_type = formData.get('document_type');
        const document_name = formData.get('document_name');
        const original_filename = formData.get('original_filename');
        const file_size = parseInt(formData.get('file_size'));
        const mime_type = formData.get('mime_type');
        const description = formData.get('description') || undefined;
        // First upload the file
        const uploadResult = await uploadFile(file);
        if (!uploadResult.success) {
            throw new Error(uploadResult.error || "File upload failed");
        }
        // Create document record
        const collection = await database?.collection("employee_documents");
        const document = {
            employee_id,
            document_type,
            document_name,
            original_filename,
            file_path: uploadResult.filePath,
            file_size,
            mime_type,
            description,
            uploaded_at: new Date(),
            is_active: true
        };
        // Validate with Zod schema
        const validatedData = __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["EmployeeDocumentSchema"].parse(document);
        const result = await collection.insertOne(validatedData);
        return {
            insertedId: result.insertedId.toString(),
            success: true
        };
    } catch (error) {
        console.error("Error creating employee document:", error.message);
        return {
            error: error.message
        };
    }
};
const getEmployeeDocumentById = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const document = await collection.findOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        });
        return document ? {
            ...document,
            _id: document._id.toString(),
            employee_id: document.employee_id.toString()
        } : null;
    } catch (error) {
        console.error("Error fetching employee document:", error.message);
        return {
            error: error.message
        };
    }
};
const updateEmployeeDocument = async (id, updateData)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: updateData
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error updating employee document:", error.message);
        return {
            error: error.message
        };
    }
};
const deleteEmployeeDocument = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                is_active: false
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error deleting employee document:", error.message);
        return {
            error: error.message
        };
    }
};
const getAllEmployeeDocuments = async (employeeId, includeInactive = false)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const filter = {
            employee_id: employeeId
        };
        if (!includeInactive) {
            filter.is_active = {
                $ne: false
            };
        }
        const documents = await collection.find(filter).toArray();
        return documents.map((doc)=>({
                ...doc,
                _id: doc._id.toString(),
                employee_id: doc.employee_id.toString()
            }));
    } catch (error) {
        console.error("Error fetching employee documents:", error.message);
        return {
            error: error.message
        };
    }
};
const getDocumentsByType = async (employeeId, documentType, includeInactive = false)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const filter = {
            employee_id: employeeId,
            document_type: documentType
        };
        if (!includeInactive) {
            filter.is_active = {
                $ne: false
            };
        }
        const documents = await collection.find(filter).toArray();
        return documents.map((doc)=>({
                ...doc,
                _id: doc._id.toString(),
                employee_id: doc.employee_id.toString()
            }));
    } catch (error) {
        console.error("Error fetching documents by type:", error.message);
        return {
            error: error.message
        };
    }
};
const getActiveDocumentTypesForEmployee = async (employeeId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employee_documents");
        const result = await collection.aggregate([
            {
                $match: {
                    employee_id: employeeId,
                    is_active: true
                }
            },
            {
                $group: {
                    _id: "$document_type"
                }
            }
        ]).toArray();
        return result.map((item)=>item._id);
    } catch (error) {
        console.error("Error fetching active document types:", error.message);
        return {
            error: error.message
        };
    }
};
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    createEmployeeDocument,
    getEmployeeDocumentById,
    updateEmployeeDocument,
    deleteEmployeeDocument,
    getAllEmployeeDocuments,
    getDocumentsByType,
    getActiveDocumentTypesForEmployee
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createEmployeeDocument, "7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeeDocumentById, "7f6f8cff0e1265ee5f173fa28997adb3a311698f5e", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(updateEmployeeDocument, "7f58cfb79edce26b57876bab68bf741d40f865b1fc", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deleteEmployeeDocument, "7f6ccbe79e36dcf5799d740bcdb8e39a6952514711", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getAllEmployeeDocuments, "7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getDocumentsByType, "7feb75fa17bd2c20f93ea61edafde4c5e91095ab45", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getActiveDocumentTypesForEmployee, "7f2185529f04a4ef46cf01097ddb1a1b401002056c", null);
}}),
"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f07033d9c73c17a63f43a9cfa5012cb6cfef258c2":"updateEmployee","7f216b9e67a84dc38e0c070d8ac699330adbc59d0d":"getEmployeeById","7f4b7cc6a48ce840cd9bc8a27ccaed90acf597d14b":"deleteEmployee","7f5fa9459441e3aae9593059298f1c5b5414b1e9f7":"getAllEmployees","7fd73fd02f8b69452d3050b76c08df4aa935d6c24d":"getEmployeesByDepartment","7fe73a856bb5a41421c36b83c716fffe022a846e45":"createEmployee"},"",""] */ __turbopack_context__.s({
    "createEmployee": (()=>createEmployee),
    "deleteEmployee": (()=>deleteEmployee),
    "getAllEmployees": (()=>getAllEmployees),
    "getEmployeeById": (()=>getEmployeeById),
    "getEmployeesByDepartment": (()=>getEmployeesByDepartment),
    "updateEmployee": (()=>updateEmployee)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
let dbConnection;
let database;
const init = async ()=>{
    try {
        const connection = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["connectToDB"])();
        dbConnection = connection;
        database = await dbConnection?.db("hr_management_db");
    } catch (error) {
        console.error("Database connection failed:", error);
        throw error;
    }
};
const createEmployee = async (employeeData)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const employee = {
            ...employeeData,
            createdAt: new Date(),
            updatedAt: new Date(),
            isActive: true
        };
        const result = await collection.insertOne(employee);
        return {
            insertedId: result.insertedId.toString(),
            success: true
        };
    } catch (error) {
        console.error("Error creating employee:", error.message);
        return {
            error: error.message
        };
    }
};
const getEmployeeById = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const employee = await collection.findOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        });
        return employee ? {
            ...employee,
            _id: employee._id.toString()
        } : null;
    } catch (error) {
        console.error("Error fetching employee:", error.message);
        return {
            error: error.message
        };
    }
};
const updateEmployee = async (id, updateData)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                ...updateData,
                updatedAt: new Date()
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error updating employee:", error.message);
        return {
            error: error.message
        };
    }
};
const deleteEmployee = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                isActive: false,
                deletedAt: new Date()
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error deleting employee:", error.message);
        return {
            error: error.message
        };
    }
};
const getAllEmployees = async (includeInactive = false)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const positionCollection = await database?.collection("positions");
        const departmentCollection = await database?.collection("departments");
        const filter = includeInactive ? {} : {
            isActive: {
                $ne: false
            }
        };
        const employees = await collection.find(filter).toArray();
        // Enhance employees with department and position names
        const enhancedEmployees = await Promise.all(employees.map(async (employee)=>{
            // Try both field name variations to handle inconsistencies
            const positionId = employee.positionId || employee.position_id;
            const departmentId = employee.departmentId || employee.department_id;
            const position = positionId ? await positionCollection.findOne({
                _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](positionId)
            }) : null;
            const department = departmentId ? await departmentCollection.findOne({
                _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](departmentId)
            }) : null;
            return {
                ...employee,
                _id: employee._id.toString(),
                // Ensure these field names match what your columns expect
                position_title: position?.position_title || "Unknown",
                department_name: department?.department_name || "Unknown",
                manager_name: employee.managerId ? await getEmployeeName(employee.managerId) : null,
                // Include the original IDs for reference
                positionId: positionId,
                departmentId: departmentId
            };
        }));
        return enhancedEmployees;
    } catch (error) {
        console.error("Error fetching employees:", error.message);
        return {
            error: error.message
        };
    }
};
async function getEmployeeName(employeeId) {
    const collection = await database?.collection("employees");
    const employee = await collection.findOne({
        _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeId)
    });
    return employee ? `${employee.firstName} ${employee.lastName}` : null;
}
const getEmployeesByDepartment = async (departmentId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const employees = await collection.find({
            departmentId: departmentId,
            isActive: {
                $ne: false
            }
        }).toArray();
        return employees.map((employee)=>({
                ...employee,
                _id: employee._id.toString()
            }));
    } catch (error) {
        console.error("Error fetching department employees:", error.message);
        return {
            error: error.message
        };
    }
};
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    createEmployee,
    getEmployeeById,
    updateEmployee,
    deleteEmployee,
    getAllEmployees,
    getEmployeesByDepartment
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createEmployee, "7fe73a856bb5a41421c36b83c716fffe022a846e45", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeeById, "7f216b9e67a84dc38e0c070d8ac699330adbc59d0d", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(updateEmployee, "7f07033d9c73c17a63f43a9cfa5012cb6cfef258c2", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deleteEmployee, "7f4b7cc6a48ce840cd9bc8a27ccaed90acf597d14b", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getAllEmployees, "7f5fa9459441e3aae9593059298f1c5b5414b1e9f7", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeesByDepartment, "7fd73fd02f8b69452d3050b76c08df4aa935d6c24d", null);
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.actions.ts [app-rsc] (ecmascript)");
;
;
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <exports>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "7f5fa9459441e3aae9593059298f1c5b5414b1e9f7": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAllEmployees"]),
    "7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createEmployeeDocument"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "7f5fa9459441e3aae9593059298f1c5b5414b1e9f7": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f5fa9459441e3aae9593059298f1c5b5414b1e9f7"]),
    "7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7f9664d558512bb9525a14e45cf21aa43fa4b2e7f2"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <module evaluation>');
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$documents$2e$actons$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employee-documents/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.documents.actons.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <exports>');
}}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/(admin)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/(admin)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/(admin)/employee-documents/create/page.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/app/(protected)/(admin)/employee-documents/create/page.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/(protected)/(admin)/employee-documents/create/page.tsx <module evaluation>", "default");
}}),
"[project]/app/(protected)/(admin)/employee-documents/create/page.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/app/(protected)/(admin)/employee-documents/create/page.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/(protected)/(admin)/employee-documents/create/page.tsx", "default");
}}),
"[project]/app/(protected)/(admin)/employee-documents/create/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$create$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/app/(protected)/(admin)/employee-documents/create/page.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$create$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/app/(protected)/(admin)/employee-documents/create/page.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employee$2d$documents$2f$create$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/app/(protected)/(admin)/employee-documents/create/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/(admin)/employee-documents/create/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__017fa20d._.js.map