module.exports = {

"[project]/lib/utils.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "cn": (()=>cn)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}}),
"[project]/components/ui/button.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Button": (()=>Button),
    "buttonVariants": (()=>buttonVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",
            destructive: "bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/button.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/components/ui/card.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Card": (()=>Card),
    "CardContent": (()=>CardContent),
    "CardDescription": (()=>CardDescription),
    "CardFooter": (()=>CardFooter),
    "CardHeader": (()=>CardHeader),
    "CardTitle": (()=>CardTitle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
function Card({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
function CardHeader({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col gap-1.5 px-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
function CardTitle({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("leading-none font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
function CardDescription({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
}
function CardContent({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-content",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("px-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 50,
        columnNumber: 5
    }, this);
}
function CardFooter({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex items-center px-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/components/ui/badge.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Badge": (()=>Badge),
    "badgeVariants": (()=>badgeVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const badgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center rounded-md border px-2 py-0.5 text-xs font-medium w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1 [&>svg]:pointer-events-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive transition-[color,box-shadow] overflow-auto", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground [a&]:hover:bg-primary/90",
            secondary: "border-transparent bg-secondary text-secondary-foreground [a&]:hover:bg-secondary/90",
            destructive: "border-transparent bg-destructive text-white [a&]:hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40",
            outline: "text-foreground [a&]:hover:bg-accent [a&]:hover:text-accent-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "span";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "badge",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(badgeVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/badge.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/actions/data:05c4b9 [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2":"getAllEmployeeDocuments"},"actions/employee.documents.actons.ts",""] */ __turbopack_context__.s({
    "getAllEmployeeDocuments": (()=>getAllEmployeeDocuments)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getAllEmployeeDocuments = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("7f534b5d3e14c9bc0611b6a521f2ae0aaee8cfe4b2", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getAllEmployeeDocuments"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZW1wbG95ZWUuZG9jdW1lbnRzLmFjdG9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIlxuXG5pbXBvcnQgeyBjb25uZWN0VG9EQiB9IGZyb20gXCJAL2xpYi9kYlwiO1xuaW1wb3J0IHsgT2JqZWN0SWQgfSBmcm9tIFwibW9uZ29kYlwiO1xuaW1wb3J0IHsgRW1wbG95ZWVEb2N1bWVudFNjaGVtYSwgRmlsZVVwbG9hZFNjaGVtYSB9IGZyb20gXCJAL3NjaGVtYXNcIjtcbmltcG9ydCB7IHogfSBmcm9tIFwiem9kXCI7XG5pbXBvcnQgeyBwcm9taXNlcyBhcyBmcyB9IGZyb20gJ2ZzJztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuXG5sZXQgZGJDb25uZWN0aW9uOiBhbnk7XG5sZXQgZGF0YWJhc2U6IGFueTtcblxuY29uc3QgaW5pdCA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb25uZWN0aW9uID0gYXdhaXQgY29ubmVjdFRvREIoKTtcbiAgICAgICAgZGJDb25uZWN0aW9uID0gY29ubmVjdGlvbjtcbiAgICAgICAgZGF0YWJhc2UgPSBhd2FpdCBkYkNvbm5lY3Rpb24/LmRiKFwiaHJfbWFuYWdlbWVudF9kYlwiKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgY29ubmVjdGlvbiBmYWlsZWQ6XCIsIGVycm9yKTtcbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxufVxuXG4vLyBGaWxlIHN0b3JhZ2UgZGlyZWN0b3J5IChhZGp1c3QgYXMgbmVlZGVkKVxuY29uc3QgRE9DVU1FTlRTX0RJUiA9IHBhdGguam9pbihwcm9jZXNzLmN3ZCgpLCAncHVibGljJywgJ2VtcGxveWVlLWRvY3VtZW50cycpO1xuXG4vLyBFbnN1cmUgZGlyZWN0b3J5IGV4aXN0c1xuYXN5bmMgZnVuY3Rpb24gZW5zdXJlRG9jdW1lbnRzRGlyKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGZzLm1rZGlyKERPQ1VNRU5UU19ESVIsIHsgcmVjdXJzaXZlOiB0cnVlIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBkb2N1bWVudHMgZGlyZWN0b3J5OlwiLCBlcnJvcik7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbn1cblxuLy8gRG9jdW1lbnQgQ1JVRCBPcGVyYXRpb25zXG5leHBvcnQgY29uc3QgdXBsb2FkRW1wbG95ZWVEb2N1bWVudCA9IGFzeW5jIChmb3JtRGF0YTogRm9ybURhdGEpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIGF3YWl0IGVuc3VyZURvY3VtZW50c0RpcigpO1xuXG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcGFyc2VkRGF0YSA9IEZpbGVVcGxvYWRTY2hlbWEucGFyc2Uoe1xuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGZvcm1EYXRhLmdldCgnZW1wbG95ZWVfaWQnKSxcbiAgICAgICAgICAgIGRvY3VtZW50X3R5cGU6IGZvcm1EYXRhLmdldCgnZG9jdW1lbnRfdHlwZScpLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IGZvcm1EYXRhLmdldCgnZGVzY3JpcHRpb24nKSxcbiAgICAgICAgICAgIGZpbGVzOiBmb3JtRGF0YS5nZXRBbGwoJ2ZpbGVzJylcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVfZG9jdW1lbnRzXCIpO1xuICAgICAgICBjb25zdCByZXN1bHRzID0gW107XG5cbiAgICAgICAgZm9yIChjb25zdCBmaWxlIG9mIHBhcnNlZERhdGEuZmlsZXMpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpbGVCdWZmZXIgPSBhd2FpdCBmaWxlLmFycmF5QnVmZmVyKCk7XG4gICAgICAgICAgICBjb25zdCB1bmlxdWVGaWxlbmFtZSA9IGAke0RhdGUubm93KCl9LSR7ZmlsZS5uYW1lLnJlcGxhY2UoL1xccysvZywgJy0nKX1gO1xuICAgICAgICAgICAgY29uc3QgZmlsZVBhdGggPSBwYXRoLmpvaW4oRE9DVU1FTlRTX0RJUiwgdW5pcXVlRmlsZW5hbWUpO1xuXG4gICAgICAgICAgICBhd2FpdCBmcy53cml0ZUZpbGUoZmlsZVBhdGgsIEJ1ZmZlci5mcm9tKGZpbGVCdWZmZXIpKTtcblxuICAgICAgICAgICAgY29uc3QgZG9jdW1lbnREYXRhID0ge1xuICAgICAgICAgICAgICAgIGVtcGxveWVlX2lkOiBwYXJzZWREYXRhLmVtcGxveWVlX2lkLFxuICAgICAgICAgICAgICAgIGRvY3VtZW50X3R5cGU6IHBhcnNlZERhdGEuZG9jdW1lbnRfdHlwZSxcbiAgICAgICAgICAgICAgICBkb2N1bWVudF9uYW1lOiBmaWxlLm5hbWUsXG4gICAgICAgICAgICAgICAgb3JpZ2luYWxfZmlsZW5hbWU6IGZpbGUubmFtZSxcbiAgICAgICAgICAgICAgICBmaWxlX3BhdGg6IGAvZW1wbG95ZWUtZG9jdW1lbnRzLyR7dW5pcXVlRmlsZW5hbWV9YCxcbiAgICAgICAgICAgICAgICBmaWxlX3NpemU6IGZpbGUuc2l6ZSxcbiAgICAgICAgICAgICAgICBtaW1lX3R5cGU6IGZpbGUudHlwZSxcbiAgICAgICAgICAgICAgICB1cGxvYWRlZF9hdDogbmV3IERhdGUoKSxcbiAgICAgICAgICAgICAgICB1cGxvYWRlZF9ieTogbnVsbCwgLy8gVE9ETzogQWRkIGF1dGggY29udGV4dFxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBwYXJzZWREYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgIGlzX2FjdGl2ZTogdHJ1ZVxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi5pbnNlcnRPbmUoZG9jdW1lbnREYXRhKTtcbiAgICAgICAgICAgIHJlc3VsdHMucHVzaCh7XG4gICAgICAgICAgICAgICAgaW5zZXJ0ZWRJZDogcmVzdWx0Lmluc2VydGVkSWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgICAgICBkb2N1bWVudF9uYW1lOiBmaWxlLm5hbWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgcmVzdWx0cyB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwbG9hZGluZyBkb2N1bWVudDpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZ2V0RG9jdW1lbnRCeUlkID0gYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlX2RvY3VtZW50c1wiKTtcbiAgICAgICAgY29uc3QgZG9jdW1lbnQgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmRPbmUoeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSk7XG4gICAgICAgIHJldHVybiBkb2N1bWVudCA/IHsgLi4uZG9jdW1lbnQsIF9pZDogZG9jdW1lbnQuX2lkLnRvU3RyaW5nKCkgfSA6IG51bGw7XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZG9jdW1lbnQ6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IGdldERvY3VtZW50c0J5RW1wbG95ZWUgPSBhc3luYyAoZW1wbG95ZWVJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZV9kb2N1bWVudHNcIik7XG4gICAgICAgIGNvbnN0IGRvY3VtZW50cyA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZCh7IFxuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXG4gICAgICAgICAgICBpc19hY3RpdmU6IHRydWUgXG4gICAgICAgIH0pLnRvQXJyYXkoKTtcbiAgICAgICAgXG4gICAgICAgIHJldHVybiBkb2N1bWVudHMubWFwKChkb2M6IGFueSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmRvYyxcbiAgICAgICAgICAgIF9pZDogZG9jLl9pZC50b1N0cmluZygpXG4gICAgICAgIH0pKTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZSBkb2N1bWVudHM6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IHVwZGF0ZURvY3VtZW50ID0gYXN5bmMgKFxuICAgIGlkOiBzdHJpbmcsIFxuICAgIHVwZGF0ZURhdGE6IFBhcnRpYWw8ei5pbmZlcjx0eXBlb2YgRW1wbG95ZWVEb2N1bWVudFNjaGVtYT4+XG4pID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlX2RvY3VtZW50c1wiKTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi51cGRhdGVPbmUoXG4gICAgICAgICAgICB7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9LFxuICAgICAgICAgICAgeyAkc2V0OiB7IC4uLnVwZGF0ZURhdGEsIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkgfSB9XG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiB7IG1vZGlmaWVkQ291bnQ6IHJlc3VsdC5tb2RpZmllZENvdW50LCBzdWNjZXNzOiB0cnVlIH07XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZG9jdW1lbnQ6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IGRlbGV0ZURvY3VtZW50ID0gYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlX2RvY3VtZW50c1wiKTtcbiAgICAgICAgXG4gICAgICAgIC8vIFNvZnQgZGVsZXRlIChyZWNvbW1lbmRlZClcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi51cGRhdGVPbmUoXG4gICAgICAgICAgICB7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9LFxuICAgICAgICAgICAgeyAkc2V0OiB7IGlzX2FjdGl2ZTogZmFsc2UsIGRlbGV0ZWRfYXQ6IG5ldyBEYXRlKCkgfSB9XG4gICAgICAgICk7XG4gICAgICAgIFxuICAgICAgICAvLyBBbHRlcm5hdGl2ZTogSGFyZCBkZWxldGUgd2l0aCBmaWxlIHJlbW92YWxcbiAgICAgICAgLypcbiAgICAgICAgY29uc3QgZG9jdW1lbnQgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmRPbmUoeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSk7XG4gICAgICAgIGlmIChkb2N1bWVudCkge1xuICAgICAgICAgICAgY29uc3QgZmlsZVBhdGggPSBwYXRoLmpvaW4ocHJvY2Vzcy5jd2QoKSwgJ3B1YmxpYycsIGRvY3VtZW50LmZpbGVfcGF0aCk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGF3YWl0IGZzLnVubGluayhmaWxlUGF0aCk7XG4gICAgICAgICAgICB9IGNhdGNoIChmaWxlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXCJDb3VsZCBub3QgZGVsZXRlIGZpbGU6XCIsIGZpbGVFcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi5kZWxldGVPbmUoeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSk7XG4gICAgICAgICovXG4gICAgICAgIFxuICAgICAgICByZXR1cm4geyBtb2RpZmllZENvdW50OiByZXN1bHQubW9kaWZpZWRDb3VudCwgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGRvY3VtZW50OlwiLCBlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfTtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBnZXREb2N1bWVudHNCeVR5cGUgPSBhc3luYyAoZW1wbG95ZWVJZDogc3RyaW5nLCBkb2N1bWVudFR5cGU6IHN0cmluZykgPT4ge1xuICAgIGlmICghZGJDb25uZWN0aW9uKSBhd2FpdCBpbml0KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVfZG9jdW1lbnRzXCIpO1xuICAgICAgICBjb25zdCBkb2N1bWVudHMgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmQoeyBcbiAgICAgICAgICAgIGVtcGxveWVlX2lkOiBlbXBsb3llZUlkLFxuICAgICAgICAgICAgZG9jdW1lbnRfdHlwZTogZG9jdW1lbnRUeXBlLFxuICAgICAgICAgICAgaXNfYWN0aXZlOiB0cnVlXG4gICAgICAgIH0pLnRvQXJyYXkoKTtcbiAgICAgICAgXG4gICAgICAgIHJldHVybiBkb2N1bWVudHMubWFwKChkb2M6IGFueSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmRvYyxcbiAgICAgICAgICAgIF9pZDogZG9jLl9pZC50b1N0cmluZygpXG4gICAgICAgIH0pKTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkb2N1bWVudHMgYnkgdHlwZTpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZ2V0QWxsRW1wbG95ZWVEb2N1bWVudHMgPSBhc3luYyAoZW1wbG95ZWVJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZV9kb2N1bWVudHNcIik7XG4gICAgICAgIGNvbnN0IGRvY3VtZW50cyA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZCh7IFxuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXG4gICAgICAgICAgICBpc19hY3RpdmU6IHRydWVcbiAgICAgICAgfSkuc29ydCh7IHVwbG9hZGVkX2F0OiAtMSB9KS50b0FycmF5KCk7XG5cbiAgICAgICAgLy8gQ29udmVydCBNb25nb0RCIGRvY3VtZW50cyB0byBvdXIgc2NoZW1hIGZvcm1hdFxuICAgICAgICBjb25zdCBwYXJzZWREb2N1bWVudHMgPSBkb2N1bWVudHMubWFwKChkb2M6IHsgX2lkOiB7IHRvU3RyaW5nOiAoKSA9PiBhbnk7IH07IHVwbG9hZGVkX2F0OiB7IHRvSVNPU3RyaW5nOiAoKSA9PiBhbnk7IH07IH0pID0+ICh7XG4gICAgICAgICAgICAuLi5kb2MsXG4gICAgICAgICAgICBfaWQ6IGRvYy5faWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIHVwbG9hZGVkX2F0OiBkb2MudXBsb2FkZWRfYXQudG9JU09TdHJpbmcoKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIHsgXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgICAgIGRhdGE6IHBhcnNlZERvY3VtZW50cyBhcyB6LmluZmVyPHR5cGVvZiBFbXBsb3llZURvY3VtZW50U2NoZW1hPltdIFxuICAgICAgICB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlIGRvY3VtZW50czpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IFxuICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsIFxuICAgICAgICAgICAgZXJyb3I6IGVycm9yLm1lc3NhZ2UgXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZG93bmxvYWRFbXBsb3llZURvY3VtZW50ID0gYXN5bmMgKGRvY3VtZW50SWQ6IHN0cmluZykgPT4ge1xuICAgIGlmICghZGJDb25uZWN0aW9uKSBhd2FpdCBpbml0KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVfZG9jdW1lbnRzXCIpO1xuICAgICAgICBjb25zdCBkb2N1bWVudCA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZE9uZSh7IFxuICAgICAgICAgICAgX2lkOiBuZXcgT2JqZWN0SWQoZG9jdW1lbnRJZCksXG4gICAgICAgICAgICBpc19hY3RpdmU6IHRydWVcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFkb2N1bWVudCkge1xuICAgICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRvY3VtZW50IG5vdCBmb3VuZFwiIH07XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHlvdSB3b3VsZDpcbiAgICAgICAgLy8gMS4gRm9yIGxvY2FsIGZpbGVzOiBHZW5lcmF0ZSBhIHNpZ25lZCBVUkwgb3Igc2VydmUgdGhlIGZpbGVcbiAgICAgICAgLy8gMi4gRm9yIGNsb3VkIHN0b3JhZ2U6IEdlbmVyYXRlIGEgZG93bmxvYWQgVVJMXG4gICAgICAgIC8vIEhlcmUncyBhIHNpbXBsaWZpZWQgdmVyc2lvbjpcbiAgICAgICAgcmV0dXJuIHsgXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgZG93bmxvYWRVcmw6IGRvY3VtZW50LmZpbGVfcGF0aCwgLy8gVGhpcyBzaG91bGQgYmUgdGhlIGZ1bGwgYWNjZXNzaWJsZSBVUkxcbiAgICAgICAgICAgIGZpbGVuYW1lOiBkb2N1bWVudC5vcmlnaW5hbF9maWxlbmFtZVxuICAgICAgICB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHByZXBhcmluZyBkb2N1bWVudCBkb3dubG9hZDpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuXG5leHBvcnQgY29uc3QgZGVsZXRlRW1wbG95ZWVEb2N1bWVudCA9IGFzeW5jIChpZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZV9kb2N1bWVudHNcIik7XG4gICAgICAgIFxuICAgICAgICAvLyBTb2Z0IGRlbGV0ZSAocmVjb21tZW5kZWQpXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNvbGxlY3Rpb24udXBkYXRlT25lKFxuICAgICAgICAgICAgeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSxcbiAgICAgICAgICAgIHsgJHNldDogeyBpc19hY3RpdmU6IGZhbHNlLCBkZWxldGVkX2F0OiBuZXcgRGF0ZSgpIH0gfVxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgcmV0dXJuIHsgbW9kaWZpZWRDb3VudDogcmVzdWx0Lm1vZGlmaWVkQ291bnQsIHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBkb2N1bWVudDpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoicVRBNExhIn0=
}}),
"[project]/actions/data:6af78e [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f6ccbe79e36dcf5799d740bcdb8e39a6952514711":"deleteEmployeeDocument"},"actions/employee.documents.actons.ts",""] */ __turbopack_context__.s({
    "deleteEmployeeDocument": (()=>deleteEmployeeDocument)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var deleteEmployeeDocument = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("7f6ccbe79e36dcf5799d740bcdb8e39a6952514711", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteEmployeeDocument"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZW1wbG95ZWUuZG9jdW1lbnRzLmFjdG9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIlxuXG5pbXBvcnQgeyBjb25uZWN0VG9EQiB9IGZyb20gXCJAL2xpYi9kYlwiO1xuaW1wb3J0IHsgT2JqZWN0SWQgfSBmcm9tIFwibW9uZ29kYlwiO1xuaW1wb3J0IHsgRW1wbG95ZWVEb2N1bWVudFNjaGVtYSwgRmlsZVVwbG9hZFNjaGVtYSB9IGZyb20gXCJAL3NjaGVtYXNcIjtcbmltcG9ydCB7IHogfSBmcm9tIFwiem9kXCI7XG5pbXBvcnQgeyBwcm9taXNlcyBhcyBmcyB9IGZyb20gJ2ZzJztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuXG5sZXQgZGJDb25uZWN0aW9uOiBhbnk7XG5sZXQgZGF0YWJhc2U6IGFueTtcblxuY29uc3QgaW5pdCA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb25uZWN0aW9uID0gYXdhaXQgY29ubmVjdFRvREIoKTtcbiAgICAgICAgZGJDb25uZWN0aW9uID0gY29ubmVjdGlvbjtcbiAgICAgICAgZGF0YWJhc2UgPSBhd2FpdCBkYkNvbm5lY3Rpb24/LmRiKFwiaHJfbWFuYWdlbWVudF9kYlwiKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgY29ubmVjdGlvbiBmYWlsZWQ6XCIsIGVycm9yKTtcbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxufVxuXG4vLyBGaWxlIHN0b3JhZ2UgZGlyZWN0b3J5IChhZGp1c3QgYXMgbmVlZGVkKVxuY29uc3QgRE9DVU1FTlRTX0RJUiA9IHBhdGguam9pbihwcm9jZXNzLmN3ZCgpLCAncHVibGljJywgJ2VtcGxveWVlLWRvY3VtZW50cycpO1xuXG4vLyBFbnN1cmUgZGlyZWN0b3J5IGV4aXN0c1xuYXN5bmMgZnVuY3Rpb24gZW5zdXJlRG9jdW1lbnRzRGlyKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGZzLm1rZGlyKERPQ1VNRU5UU19ESVIsIHsgcmVjdXJzaXZlOiB0cnVlIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBkb2N1bWVudHMgZGlyZWN0b3J5OlwiLCBlcnJvcik7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbn1cblxuLy8gRG9jdW1lbnQgQ1JVRCBPcGVyYXRpb25zXG5leHBvcnQgY29uc3QgdXBsb2FkRW1wbG95ZWVEb2N1bWVudCA9IGFzeW5jIChmb3JtRGF0YTogRm9ybURhdGEpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIGF3YWl0IGVuc3VyZURvY3VtZW50c0RpcigpO1xuXG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcGFyc2VkRGF0YSA9IEZpbGVVcGxvYWRTY2hlbWEucGFyc2Uoe1xuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGZvcm1EYXRhLmdldCgnZW1wbG95ZWVfaWQnKSxcbiAgICAgICAgICAgIGRvY3VtZW50X3R5cGU6IGZvcm1EYXRhLmdldCgnZG9jdW1lbnRfdHlwZScpLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IGZvcm1EYXRhLmdldCgnZGVzY3JpcHRpb24nKSxcbiAgICAgICAgICAgIGZpbGVzOiBmb3JtRGF0YS5nZXRBbGwoJ2ZpbGVzJylcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVfZG9jdW1lbnRzXCIpO1xuICAgICAgICBjb25zdCByZXN1bHRzID0gW107XG5cbiAgICAgICAgZm9yIChjb25zdCBmaWxlIG9mIHBhcnNlZERhdGEuZmlsZXMpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpbGVCdWZmZXIgPSBhd2FpdCBmaWxlLmFycmF5QnVmZmVyKCk7XG4gICAgICAgICAgICBjb25zdCB1bmlxdWVGaWxlbmFtZSA9IGAke0RhdGUubm93KCl9LSR7ZmlsZS5uYW1lLnJlcGxhY2UoL1xccysvZywgJy0nKX1gO1xuICAgICAgICAgICAgY29uc3QgZmlsZVBhdGggPSBwYXRoLmpvaW4oRE9DVU1FTlRTX0RJUiwgdW5pcXVlRmlsZW5hbWUpO1xuXG4gICAgICAgICAgICBhd2FpdCBmcy53cml0ZUZpbGUoZmlsZVBhdGgsIEJ1ZmZlci5mcm9tKGZpbGVCdWZmZXIpKTtcblxuICAgICAgICAgICAgY29uc3QgZG9jdW1lbnREYXRhID0ge1xuICAgICAgICAgICAgICAgIGVtcGxveWVlX2lkOiBwYXJzZWREYXRhLmVtcGxveWVlX2lkLFxuICAgICAgICAgICAgICAgIGRvY3VtZW50X3R5cGU6IHBhcnNlZERhdGEuZG9jdW1lbnRfdHlwZSxcbiAgICAgICAgICAgICAgICBkb2N1bWVudF9uYW1lOiBmaWxlLm5hbWUsXG4gICAgICAgICAgICAgICAgb3JpZ2luYWxfZmlsZW5hbWU6IGZpbGUubmFtZSxcbiAgICAgICAgICAgICAgICBmaWxlX3BhdGg6IGAvZW1wbG95ZWUtZG9jdW1lbnRzLyR7dW5pcXVlRmlsZW5hbWV9YCxcbiAgICAgICAgICAgICAgICBmaWxlX3NpemU6IGZpbGUuc2l6ZSxcbiAgICAgICAgICAgICAgICBtaW1lX3R5cGU6IGZpbGUudHlwZSxcbiAgICAgICAgICAgICAgICB1cGxvYWRlZF9hdDogbmV3IERhdGUoKSxcbiAgICAgICAgICAgICAgICB1cGxvYWRlZF9ieTogbnVsbCwgLy8gVE9ETzogQWRkIGF1dGggY29udGV4dFxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBwYXJzZWREYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgIGlzX2FjdGl2ZTogdHJ1ZVxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi5pbnNlcnRPbmUoZG9jdW1lbnREYXRhKTtcbiAgICAgICAgICAgIHJlc3VsdHMucHVzaCh7XG4gICAgICAgICAgICAgICAgaW5zZXJ0ZWRJZDogcmVzdWx0Lmluc2VydGVkSWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgICAgICBkb2N1bWVudF9uYW1lOiBmaWxlLm5hbWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgcmVzdWx0cyB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwbG9hZGluZyBkb2N1bWVudDpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZ2V0RG9jdW1lbnRCeUlkID0gYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlX2RvY3VtZW50c1wiKTtcbiAgICAgICAgY29uc3QgZG9jdW1lbnQgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmRPbmUoeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSk7XG4gICAgICAgIHJldHVybiBkb2N1bWVudCA/IHsgLi4uZG9jdW1lbnQsIF9pZDogZG9jdW1lbnQuX2lkLnRvU3RyaW5nKCkgfSA6IG51bGw7XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZG9jdW1lbnQ6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IGdldERvY3VtZW50c0J5RW1wbG95ZWUgPSBhc3luYyAoZW1wbG95ZWVJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZV9kb2N1bWVudHNcIik7XG4gICAgICAgIGNvbnN0IGRvY3VtZW50cyA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZCh7IFxuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXG4gICAgICAgICAgICBpc19hY3RpdmU6IHRydWUgXG4gICAgICAgIH0pLnRvQXJyYXkoKTtcbiAgICAgICAgXG4gICAgICAgIHJldHVybiBkb2N1bWVudHMubWFwKChkb2M6IGFueSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmRvYyxcbiAgICAgICAgICAgIF9pZDogZG9jLl9pZC50b1N0cmluZygpXG4gICAgICAgIH0pKTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZSBkb2N1bWVudHM6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IHVwZGF0ZURvY3VtZW50ID0gYXN5bmMgKFxuICAgIGlkOiBzdHJpbmcsIFxuICAgIHVwZGF0ZURhdGE6IFBhcnRpYWw8ei5pbmZlcjx0eXBlb2YgRW1wbG95ZWVEb2N1bWVudFNjaGVtYT4+XG4pID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlX2RvY3VtZW50c1wiKTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi51cGRhdGVPbmUoXG4gICAgICAgICAgICB7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9LFxuICAgICAgICAgICAgeyAkc2V0OiB7IC4uLnVwZGF0ZURhdGEsIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkgfSB9XG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiB7IG1vZGlmaWVkQ291bnQ6IHJlc3VsdC5tb2RpZmllZENvdW50LCBzdWNjZXNzOiB0cnVlIH07XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZG9jdW1lbnQ6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IGRlbGV0ZURvY3VtZW50ID0gYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlX2RvY3VtZW50c1wiKTtcbiAgICAgICAgXG4gICAgICAgIC8vIFNvZnQgZGVsZXRlIChyZWNvbW1lbmRlZClcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi51cGRhdGVPbmUoXG4gICAgICAgICAgICB7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9LFxuICAgICAgICAgICAgeyAkc2V0OiB7IGlzX2FjdGl2ZTogZmFsc2UsIGRlbGV0ZWRfYXQ6IG5ldyBEYXRlKCkgfSB9XG4gICAgICAgICk7XG4gICAgICAgIFxuICAgICAgICAvLyBBbHRlcm5hdGl2ZTogSGFyZCBkZWxldGUgd2l0aCBmaWxlIHJlbW92YWxcbiAgICAgICAgLypcbiAgICAgICAgY29uc3QgZG9jdW1lbnQgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmRPbmUoeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSk7XG4gICAgICAgIGlmIChkb2N1bWVudCkge1xuICAgICAgICAgICAgY29uc3QgZmlsZVBhdGggPSBwYXRoLmpvaW4ocHJvY2Vzcy5jd2QoKSwgJ3B1YmxpYycsIGRvY3VtZW50LmZpbGVfcGF0aCk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGF3YWl0IGZzLnVubGluayhmaWxlUGF0aCk7XG4gICAgICAgICAgICB9IGNhdGNoIChmaWxlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXCJDb3VsZCBub3QgZGVsZXRlIGZpbGU6XCIsIGZpbGVFcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi5kZWxldGVPbmUoeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSk7XG4gICAgICAgICovXG4gICAgICAgIFxuICAgICAgICByZXR1cm4geyBtb2RpZmllZENvdW50OiByZXN1bHQubW9kaWZpZWRDb3VudCwgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGRvY3VtZW50OlwiLCBlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfTtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBnZXREb2N1bWVudHNCeVR5cGUgPSBhc3luYyAoZW1wbG95ZWVJZDogc3RyaW5nLCBkb2N1bWVudFR5cGU6IHN0cmluZykgPT4ge1xuICAgIGlmICghZGJDb25uZWN0aW9uKSBhd2FpdCBpbml0KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVfZG9jdW1lbnRzXCIpO1xuICAgICAgICBjb25zdCBkb2N1bWVudHMgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmQoeyBcbiAgICAgICAgICAgIGVtcGxveWVlX2lkOiBlbXBsb3llZUlkLFxuICAgICAgICAgICAgZG9jdW1lbnRfdHlwZTogZG9jdW1lbnRUeXBlLFxuICAgICAgICAgICAgaXNfYWN0aXZlOiB0cnVlXG4gICAgICAgIH0pLnRvQXJyYXkoKTtcbiAgICAgICAgXG4gICAgICAgIHJldHVybiBkb2N1bWVudHMubWFwKChkb2M6IGFueSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmRvYyxcbiAgICAgICAgICAgIF9pZDogZG9jLl9pZC50b1N0cmluZygpXG4gICAgICAgIH0pKTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkb2N1bWVudHMgYnkgdHlwZTpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZ2V0QWxsRW1wbG95ZWVEb2N1bWVudHMgPSBhc3luYyAoZW1wbG95ZWVJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZV9kb2N1bWVudHNcIik7XG4gICAgICAgIGNvbnN0IGRvY3VtZW50cyA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZCh7IFxuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXG4gICAgICAgICAgICBpc19hY3RpdmU6IHRydWVcbiAgICAgICAgfSkuc29ydCh7IHVwbG9hZGVkX2F0OiAtMSB9KS50b0FycmF5KCk7XG5cbiAgICAgICAgLy8gQ29udmVydCBNb25nb0RCIGRvY3VtZW50cyB0byBvdXIgc2NoZW1hIGZvcm1hdFxuICAgICAgICBjb25zdCBwYXJzZWREb2N1bWVudHMgPSBkb2N1bWVudHMubWFwKChkb2M6IHsgX2lkOiB7IHRvU3RyaW5nOiAoKSA9PiBhbnk7IH07IHVwbG9hZGVkX2F0OiB7IHRvSVNPU3RyaW5nOiAoKSA9PiBhbnk7IH07IH0pID0+ICh7XG4gICAgICAgICAgICAuLi5kb2MsXG4gICAgICAgICAgICBfaWQ6IGRvYy5faWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIHVwbG9hZGVkX2F0OiBkb2MudXBsb2FkZWRfYXQudG9JU09TdHJpbmcoKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIHsgXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgICAgIGRhdGE6IHBhcnNlZERvY3VtZW50cyBhcyB6LmluZmVyPHR5cGVvZiBFbXBsb3llZURvY3VtZW50U2NoZW1hPltdIFxuICAgICAgICB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlIGRvY3VtZW50czpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IFxuICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsIFxuICAgICAgICAgICAgZXJyb3I6IGVycm9yLm1lc3NhZ2UgXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZG93bmxvYWRFbXBsb3llZURvY3VtZW50ID0gYXN5bmMgKGRvY3VtZW50SWQ6IHN0cmluZykgPT4ge1xuICAgIGlmICghZGJDb25uZWN0aW9uKSBhd2FpdCBpbml0KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVfZG9jdW1lbnRzXCIpO1xuICAgICAgICBjb25zdCBkb2N1bWVudCA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZE9uZSh7IFxuICAgICAgICAgICAgX2lkOiBuZXcgT2JqZWN0SWQoZG9jdW1lbnRJZCksXG4gICAgICAgICAgICBpc19hY3RpdmU6IHRydWVcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFkb2N1bWVudCkge1xuICAgICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRvY3VtZW50IG5vdCBmb3VuZFwiIH07XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHlvdSB3b3VsZDpcbiAgICAgICAgLy8gMS4gRm9yIGxvY2FsIGZpbGVzOiBHZW5lcmF0ZSBhIHNpZ25lZCBVUkwgb3Igc2VydmUgdGhlIGZpbGVcbiAgICAgICAgLy8gMi4gRm9yIGNsb3VkIHN0b3JhZ2U6IEdlbmVyYXRlIGEgZG93bmxvYWQgVVJMXG4gICAgICAgIC8vIEhlcmUncyBhIHNpbXBsaWZpZWQgdmVyc2lvbjpcbiAgICAgICAgcmV0dXJuIHsgXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgZG93bmxvYWRVcmw6IGRvY3VtZW50LmZpbGVfcGF0aCwgLy8gVGhpcyBzaG91bGQgYmUgdGhlIGZ1bGwgYWNjZXNzaWJsZSBVUkxcbiAgICAgICAgICAgIGZpbGVuYW1lOiBkb2N1bWVudC5vcmlnaW5hbF9maWxlbmFtZVxuICAgICAgICB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHByZXBhcmluZyBkb2N1bWVudCBkb3dubG9hZDpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuXG5leHBvcnQgY29uc3QgZGVsZXRlRW1wbG95ZWVEb2N1bWVudCA9IGFzeW5jIChpZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZV9kb2N1bWVudHNcIik7XG4gICAgICAgIFxuICAgICAgICAvLyBTb2Z0IGRlbGV0ZSAocmVjb21tZW5kZWQpXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNvbGxlY3Rpb24udXBkYXRlT25lKFxuICAgICAgICAgICAgeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSxcbiAgICAgICAgICAgIHsgJHNldDogeyBpc19hY3RpdmU6IGZhbHNlLCBkZWxldGVkX2F0OiBuZXcgRGF0ZSgpIH0gfVxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgcmV0dXJuIHsgbW9kaWZpZWRDb3VudDogcmVzdWx0Lm1vZGlmaWVkQ291bnQsIHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBkb2N1bWVudDpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoib1RBc1BhIn0=
}}),
"[project]/actions/data:80ae03 [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7feaacf192c8bd439d8b052515ddc7dfc51656232c":"downloadEmployeeDocument"},"actions/employee.documents.actons.ts",""] */ __turbopack_context__.s({
    "downloadEmployeeDocument": (()=>downloadEmployeeDocument)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var downloadEmployeeDocument = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("7feaacf192c8bd439d8b052515ddc7dfc51656232c", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "downloadEmployeeDocument"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZW1wbG95ZWUuZG9jdW1lbnRzLmFjdG9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIlxuXG5pbXBvcnQgeyBjb25uZWN0VG9EQiB9IGZyb20gXCJAL2xpYi9kYlwiO1xuaW1wb3J0IHsgT2JqZWN0SWQgfSBmcm9tIFwibW9uZ29kYlwiO1xuaW1wb3J0IHsgRW1wbG95ZWVEb2N1bWVudFNjaGVtYSwgRmlsZVVwbG9hZFNjaGVtYSB9IGZyb20gXCJAL3NjaGVtYXNcIjtcbmltcG9ydCB7IHogfSBmcm9tIFwiem9kXCI7XG5pbXBvcnQgeyBwcm9taXNlcyBhcyBmcyB9IGZyb20gJ2ZzJztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuXG5sZXQgZGJDb25uZWN0aW9uOiBhbnk7XG5sZXQgZGF0YWJhc2U6IGFueTtcblxuY29uc3QgaW5pdCA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb25uZWN0aW9uID0gYXdhaXQgY29ubmVjdFRvREIoKTtcbiAgICAgICAgZGJDb25uZWN0aW9uID0gY29ubmVjdGlvbjtcbiAgICAgICAgZGF0YWJhc2UgPSBhd2FpdCBkYkNvbm5lY3Rpb24/LmRiKFwiaHJfbWFuYWdlbWVudF9kYlwiKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgY29ubmVjdGlvbiBmYWlsZWQ6XCIsIGVycm9yKTtcbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxufVxuXG4vLyBGaWxlIHN0b3JhZ2UgZGlyZWN0b3J5IChhZGp1c3QgYXMgbmVlZGVkKVxuY29uc3QgRE9DVU1FTlRTX0RJUiA9IHBhdGguam9pbihwcm9jZXNzLmN3ZCgpLCAncHVibGljJywgJ2VtcGxveWVlLWRvY3VtZW50cycpO1xuXG4vLyBFbnN1cmUgZGlyZWN0b3J5IGV4aXN0c1xuYXN5bmMgZnVuY3Rpb24gZW5zdXJlRG9jdW1lbnRzRGlyKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGZzLm1rZGlyKERPQ1VNRU5UU19ESVIsIHsgcmVjdXJzaXZlOiB0cnVlIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBkb2N1bWVudHMgZGlyZWN0b3J5OlwiLCBlcnJvcik7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbn1cblxuLy8gRG9jdW1lbnQgQ1JVRCBPcGVyYXRpb25zXG5leHBvcnQgY29uc3QgdXBsb2FkRW1wbG95ZWVEb2N1bWVudCA9IGFzeW5jIChmb3JtRGF0YTogRm9ybURhdGEpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIGF3YWl0IGVuc3VyZURvY3VtZW50c0RpcigpO1xuXG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcGFyc2VkRGF0YSA9IEZpbGVVcGxvYWRTY2hlbWEucGFyc2Uoe1xuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGZvcm1EYXRhLmdldCgnZW1wbG95ZWVfaWQnKSxcbiAgICAgICAgICAgIGRvY3VtZW50X3R5cGU6IGZvcm1EYXRhLmdldCgnZG9jdW1lbnRfdHlwZScpLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IGZvcm1EYXRhLmdldCgnZGVzY3JpcHRpb24nKSxcbiAgICAgICAgICAgIGZpbGVzOiBmb3JtRGF0YS5nZXRBbGwoJ2ZpbGVzJylcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVfZG9jdW1lbnRzXCIpO1xuICAgICAgICBjb25zdCByZXN1bHRzID0gW107XG5cbiAgICAgICAgZm9yIChjb25zdCBmaWxlIG9mIHBhcnNlZERhdGEuZmlsZXMpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpbGVCdWZmZXIgPSBhd2FpdCBmaWxlLmFycmF5QnVmZmVyKCk7XG4gICAgICAgICAgICBjb25zdCB1bmlxdWVGaWxlbmFtZSA9IGAke0RhdGUubm93KCl9LSR7ZmlsZS5uYW1lLnJlcGxhY2UoL1xccysvZywgJy0nKX1gO1xuICAgICAgICAgICAgY29uc3QgZmlsZVBhdGggPSBwYXRoLmpvaW4oRE9DVU1FTlRTX0RJUiwgdW5pcXVlRmlsZW5hbWUpO1xuXG4gICAgICAgICAgICBhd2FpdCBmcy53cml0ZUZpbGUoZmlsZVBhdGgsIEJ1ZmZlci5mcm9tKGZpbGVCdWZmZXIpKTtcblxuICAgICAgICAgICAgY29uc3QgZG9jdW1lbnREYXRhID0ge1xuICAgICAgICAgICAgICAgIGVtcGxveWVlX2lkOiBwYXJzZWREYXRhLmVtcGxveWVlX2lkLFxuICAgICAgICAgICAgICAgIGRvY3VtZW50X3R5cGU6IHBhcnNlZERhdGEuZG9jdW1lbnRfdHlwZSxcbiAgICAgICAgICAgICAgICBkb2N1bWVudF9uYW1lOiBmaWxlLm5hbWUsXG4gICAgICAgICAgICAgICAgb3JpZ2luYWxfZmlsZW5hbWU6IGZpbGUubmFtZSxcbiAgICAgICAgICAgICAgICBmaWxlX3BhdGg6IGAvZW1wbG95ZWUtZG9jdW1lbnRzLyR7dW5pcXVlRmlsZW5hbWV9YCxcbiAgICAgICAgICAgICAgICBmaWxlX3NpemU6IGZpbGUuc2l6ZSxcbiAgICAgICAgICAgICAgICBtaW1lX3R5cGU6IGZpbGUudHlwZSxcbiAgICAgICAgICAgICAgICB1cGxvYWRlZF9hdDogbmV3IERhdGUoKSxcbiAgICAgICAgICAgICAgICB1cGxvYWRlZF9ieTogbnVsbCwgLy8gVE9ETzogQWRkIGF1dGggY29udGV4dFxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBwYXJzZWREYXRhLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgIGlzX2FjdGl2ZTogdHJ1ZVxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi5pbnNlcnRPbmUoZG9jdW1lbnREYXRhKTtcbiAgICAgICAgICAgIHJlc3VsdHMucHVzaCh7XG4gICAgICAgICAgICAgICAgaW5zZXJ0ZWRJZDogcmVzdWx0Lmluc2VydGVkSWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgICAgICBkb2N1bWVudF9uYW1lOiBmaWxlLm5hbWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgcmVzdWx0cyB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwbG9hZGluZyBkb2N1bWVudDpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZ2V0RG9jdW1lbnRCeUlkID0gYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlX2RvY3VtZW50c1wiKTtcbiAgICAgICAgY29uc3QgZG9jdW1lbnQgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmRPbmUoeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSk7XG4gICAgICAgIHJldHVybiBkb2N1bWVudCA/IHsgLi4uZG9jdW1lbnQsIF9pZDogZG9jdW1lbnQuX2lkLnRvU3RyaW5nKCkgfSA6IG51bGw7XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZG9jdW1lbnQ6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IGdldERvY3VtZW50c0J5RW1wbG95ZWUgPSBhc3luYyAoZW1wbG95ZWVJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZV9kb2N1bWVudHNcIik7XG4gICAgICAgIGNvbnN0IGRvY3VtZW50cyA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZCh7IFxuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXG4gICAgICAgICAgICBpc19hY3RpdmU6IHRydWUgXG4gICAgICAgIH0pLnRvQXJyYXkoKTtcbiAgICAgICAgXG4gICAgICAgIHJldHVybiBkb2N1bWVudHMubWFwKChkb2M6IGFueSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmRvYyxcbiAgICAgICAgICAgIF9pZDogZG9jLl9pZC50b1N0cmluZygpXG4gICAgICAgIH0pKTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZSBkb2N1bWVudHM6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IHVwZGF0ZURvY3VtZW50ID0gYXN5bmMgKFxuICAgIGlkOiBzdHJpbmcsIFxuICAgIHVwZGF0ZURhdGE6IFBhcnRpYWw8ei5pbmZlcjx0eXBlb2YgRW1wbG95ZWVEb2N1bWVudFNjaGVtYT4+XG4pID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlX2RvY3VtZW50c1wiKTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi51cGRhdGVPbmUoXG4gICAgICAgICAgICB7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9LFxuICAgICAgICAgICAgeyAkc2V0OiB7IC4uLnVwZGF0ZURhdGEsIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkgfSB9XG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiB7IG1vZGlmaWVkQ291bnQ6IHJlc3VsdC5tb2RpZmllZENvdW50LCBzdWNjZXNzOiB0cnVlIH07XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZG9jdW1lbnQ6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IGRlbGV0ZURvY3VtZW50ID0gYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlX2RvY3VtZW50c1wiKTtcbiAgICAgICAgXG4gICAgICAgIC8vIFNvZnQgZGVsZXRlIChyZWNvbW1lbmRlZClcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi51cGRhdGVPbmUoXG4gICAgICAgICAgICB7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9LFxuICAgICAgICAgICAgeyAkc2V0OiB7IGlzX2FjdGl2ZTogZmFsc2UsIGRlbGV0ZWRfYXQ6IG5ldyBEYXRlKCkgfSB9XG4gICAgICAgICk7XG4gICAgICAgIFxuICAgICAgICAvLyBBbHRlcm5hdGl2ZTogSGFyZCBkZWxldGUgd2l0aCBmaWxlIHJlbW92YWxcbiAgICAgICAgLypcbiAgICAgICAgY29uc3QgZG9jdW1lbnQgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmRPbmUoeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSk7XG4gICAgICAgIGlmIChkb2N1bWVudCkge1xuICAgICAgICAgICAgY29uc3QgZmlsZVBhdGggPSBwYXRoLmpvaW4ocHJvY2Vzcy5jd2QoKSwgJ3B1YmxpYycsIGRvY3VtZW50LmZpbGVfcGF0aCk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGF3YWl0IGZzLnVubGluayhmaWxlUGF0aCk7XG4gICAgICAgICAgICB9IGNhdGNoIChmaWxlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXCJDb3VsZCBub3QgZGVsZXRlIGZpbGU6XCIsIGZpbGVFcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi5kZWxldGVPbmUoeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSk7XG4gICAgICAgICovXG4gICAgICAgIFxuICAgICAgICByZXR1cm4geyBtb2RpZmllZENvdW50OiByZXN1bHQubW9kaWZpZWRDb3VudCwgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGRvY3VtZW50OlwiLCBlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfTtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBnZXREb2N1bWVudHNCeVR5cGUgPSBhc3luYyAoZW1wbG95ZWVJZDogc3RyaW5nLCBkb2N1bWVudFR5cGU6IHN0cmluZykgPT4ge1xuICAgIGlmICghZGJDb25uZWN0aW9uKSBhd2FpdCBpbml0KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVfZG9jdW1lbnRzXCIpO1xuICAgICAgICBjb25zdCBkb2N1bWVudHMgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmQoeyBcbiAgICAgICAgICAgIGVtcGxveWVlX2lkOiBlbXBsb3llZUlkLFxuICAgICAgICAgICAgZG9jdW1lbnRfdHlwZTogZG9jdW1lbnRUeXBlLFxuICAgICAgICAgICAgaXNfYWN0aXZlOiB0cnVlXG4gICAgICAgIH0pLnRvQXJyYXkoKTtcbiAgICAgICAgXG4gICAgICAgIHJldHVybiBkb2N1bWVudHMubWFwKChkb2M6IGFueSkgPT4gKHtcbiAgICAgICAgICAgIC4uLmRvYyxcbiAgICAgICAgICAgIF9pZDogZG9jLl9pZC50b1N0cmluZygpXG4gICAgICAgIH0pKTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkb2N1bWVudHMgYnkgdHlwZTpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZ2V0QWxsRW1wbG95ZWVEb2N1bWVudHMgPSBhc3luYyAoZW1wbG95ZWVJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZV9kb2N1bWVudHNcIik7XG4gICAgICAgIGNvbnN0IGRvY3VtZW50cyA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZCh7IFxuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXG4gICAgICAgICAgICBpc19hY3RpdmU6IHRydWVcbiAgICAgICAgfSkuc29ydCh7IHVwbG9hZGVkX2F0OiAtMSB9KS50b0FycmF5KCk7XG5cbiAgICAgICAgLy8gQ29udmVydCBNb25nb0RCIGRvY3VtZW50cyB0byBvdXIgc2NoZW1hIGZvcm1hdFxuICAgICAgICBjb25zdCBwYXJzZWREb2N1bWVudHMgPSBkb2N1bWVudHMubWFwKChkb2M6IHsgX2lkOiB7IHRvU3RyaW5nOiAoKSA9PiBhbnk7IH07IHVwbG9hZGVkX2F0OiB7IHRvSVNPU3RyaW5nOiAoKSA9PiBhbnk7IH07IH0pID0+ICh7XG4gICAgICAgICAgICAuLi5kb2MsXG4gICAgICAgICAgICBfaWQ6IGRvYy5faWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIHVwbG9hZGVkX2F0OiBkb2MudXBsb2FkZWRfYXQudG9JU09TdHJpbmcoKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIHsgXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLCBcbiAgICAgICAgICAgIGRhdGE6IHBhcnNlZERvY3VtZW50cyBhcyB6LmluZmVyPHR5cGVvZiBFbXBsb3llZURvY3VtZW50U2NoZW1hPltdIFxuICAgICAgICB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlIGRvY3VtZW50czpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IFxuICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsIFxuICAgICAgICAgICAgZXJyb3I6IGVycm9yLm1lc3NhZ2UgXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZG93bmxvYWRFbXBsb3llZURvY3VtZW50ID0gYXN5bmMgKGRvY3VtZW50SWQ6IHN0cmluZykgPT4ge1xuICAgIGlmICghZGJDb25uZWN0aW9uKSBhd2FpdCBpbml0KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVfZG9jdW1lbnRzXCIpO1xuICAgICAgICBjb25zdCBkb2N1bWVudCA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZE9uZSh7IFxuICAgICAgICAgICAgX2lkOiBuZXcgT2JqZWN0SWQoZG9jdW1lbnRJZCksXG4gICAgICAgICAgICBpc19hY3RpdmU6IHRydWVcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFkb2N1bWVudCkge1xuICAgICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkRvY3VtZW50IG5vdCBmb3VuZFwiIH07XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHlvdSB3b3VsZDpcbiAgICAgICAgLy8gMS4gRm9yIGxvY2FsIGZpbGVzOiBHZW5lcmF0ZSBhIHNpZ25lZCBVUkwgb3Igc2VydmUgdGhlIGZpbGVcbiAgICAgICAgLy8gMi4gRm9yIGNsb3VkIHN0b3JhZ2U6IEdlbmVyYXRlIGEgZG93bmxvYWQgVVJMXG4gICAgICAgIC8vIEhlcmUncyBhIHNpbXBsaWZpZWQgdmVyc2lvbjpcbiAgICAgICAgcmV0dXJuIHsgXG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgZG93bmxvYWRVcmw6IGRvY3VtZW50LmZpbGVfcGF0aCwgLy8gVGhpcyBzaG91bGQgYmUgdGhlIGZ1bGwgYWNjZXNzaWJsZSBVUkxcbiAgICAgICAgICAgIGZpbGVuYW1lOiBkb2N1bWVudC5vcmlnaW5hbF9maWxlbmFtZVxuICAgICAgICB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHByZXBhcmluZyBkb2N1bWVudCBkb3dubG9hZDpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuXG5leHBvcnQgY29uc3QgZGVsZXRlRW1wbG95ZWVEb2N1bWVudCA9IGFzeW5jIChpZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZV9kb2N1bWVudHNcIik7XG4gICAgICAgIFxuICAgICAgICAvLyBTb2Z0IGRlbGV0ZSAocmVjb21tZW5kZWQpXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNvbGxlY3Rpb24udXBkYXRlT25lKFxuICAgICAgICAgICAgeyBfaWQ6IG5ldyBPYmplY3RJZChpZCkgfSxcbiAgICAgICAgICAgIHsgJHNldDogeyBpc19hY3RpdmU6IGZhbHNlLCBkZWxldGVkX2F0OiBuZXcgRGF0ZSgpIH0gfVxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgcmV0dXJuIHsgbW9kaWZpZWRDb3VudDogcmVzdWx0Lm1vZGlmaWVkQ291bnQsIHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBkb2N1bWVudDpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoic1RBeU5hIn0=
}}),
"[project]/components/ui/alert-dialog.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "AlertDialog": (()=>AlertDialog),
    "AlertDialogAction": (()=>AlertDialogAction),
    "AlertDialogCancel": (()=>AlertDialogCancel),
    "AlertDialogContent": (()=>AlertDialogContent),
    "AlertDialogDescription": (()=>AlertDialogDescription),
    "AlertDialogFooter": (()=>AlertDialogFooter),
    "AlertDialogHeader": (()=>AlertDialogHeader),
    "AlertDialogOverlay": (()=>AlertDialogOverlay),
    "AlertDialogPortal": (()=>AlertDialogPortal),
    "AlertDialogTitle": (()=>AlertDialogTitle),
    "AlertDialogTrigger": (()=>AlertDialogTrigger)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-alert-dialog/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function AlertDialog({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "alert-dialog",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 12,
        columnNumber: 10
    }, this);
}
function AlertDialogTrigger({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "alert-dialog-trigger",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
function AlertDialogPortal({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Portal"], {
        "data-slot": "alert-dialog-portal",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
function AlertDialogOverlay({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Overlay"], {
        "data-slot": "alert-dialog-overlay",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
function AlertDialogContent({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AlertDialogPortal, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AlertDialogOverlay, {}, void 0, false, {
                fileName: "[project]/components/ui/alert-dialog.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"], {
                "data-slot": "alert-dialog-content",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg", className),
                ...props
            }, void 0, false, {
                fileName: "[project]/components/ui/alert-dialog.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
function AlertDialogHeader({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "alert-dialog-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col gap-2 text-center sm:text-left", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
}
function AlertDialogFooter({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "alert-dialog-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
function AlertDialogTitle({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"], {
        "data-slot": "alert-dialog-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-lg font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 100,
        columnNumber: 5
    }, this);
}
function AlertDialogDescription({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"], {
        "data-slot": "alert-dialog-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 113,
        columnNumber: 5
    }, this);
}
function AlertDialogAction({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Action"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["buttonVariants"])(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 126,
        columnNumber: 5
    }, this);
}
function AlertDialogCancel({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cancel"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["buttonVariants"])({
            variant: "outline"
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 138,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/app/(protected)/(admin)/employee-documents/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "EmployeeDocumentsList": (()=>EmployeeDocumentsList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/badge.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/file-text.js [app-ssr] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-ssr] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-ssr] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-ssr] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-ssr] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$folder$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderOpen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/folder-open.js [app-ssr] (ecmascript) <export default as FolderOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-ssr] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$data$3a$05c4b9__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/actions/data:05c4b9 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$data$3a$6af78e__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/actions/data:6af78e [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$data$3a$80ae03__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/actions/data:80ae03 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/alert-dialog.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
const DOCUMENT_TYPE_LABELS = {
    qualifications: 'Qualifications & Certificates',
    identity: 'Identity Documents',
    contracts: 'Employment Contracts',
    medical: 'Medical Records',
    references: 'References & Recommendations',
    other: 'Other Documents'
};
const DOCUMENT_TYPE_COLORS = {
    qualifications: 'bg-blue-100 text-blue-800',
    identity: 'bg-green-100 text-green-800',
    contracts: 'bg-purple-100 text-purple-800',
    medical: 'bg-red-100 text-red-800',
    references: 'bg-yellow-100 text-yellow-800',
    other: 'bg-gray-100 text-gray-800'
};
function EmployeeDocumentsList({ employeeId, refreshTrigger }) {
    const [documents, setDocuments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [deletingId, setDeletingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [previewDocument, setPreviewDocument] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchDocuments = async ()=>{
            try {
                setLoading(true);
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$data$3a$05c4b9__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getAllEmployeeDocuments"])(employeeId);
                if (result.success) {
                    setDocuments(result.data || []);
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(result.error || "Failed to load documents");
                }
            } catch (error) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("An error occurred while loading documents");
                console.error(error);
            } finally{
                setLoading(false);
            }
        };
        fetchDocuments();
    }, [
        employeeId,
        refreshTrigger
    ]);
    const handleDownload = async (document)=>{
        try {
            const toastId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].loading("Preparing download...");
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$data$3a$80ae03__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["downloadEmployeeDocument"])(document._id);
            if (result?.success) {
                const link = document.createElement('a');
                link.href = result.downloadUrl;
                link.download = document.original_filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("Download started", {
                    id: toastId
                });
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(result?.error || "Failed to download document", {
                    id: toastId
                });
            }
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("An error occurred during download");
            console.error(error);
        }
    };
    const handleDelete = async (documentId)=>{
        try {
            setDeletingId(documentId);
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$data$3a$6af78e__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["deleteEmployeeDocument"])(documentId);
            if (result?.success) {
                setDocuments((prev)=>prev.filter((doc)=>doc._id !== documentId));
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("Document deleted successfully");
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(result?.error || "Failed to delete document");
            }
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("An error occurred while deleting document");
            console.error(error);
        } finally{
            setDeletingId(null);
        }
    };
    const formatFileSize = (bytes)=>{
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = [
            'Bytes',
            'KB',
            'MB',
            'GB'
        ];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };
    const formatDate = (date)=>{
        return new Date(date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };
    // Group documents by type for better organization
    const groupedDocuments = documents.reduce((acc, doc)=>{
        (acc[doc.document_type] = acc[doc.document_type] || []).push(doc);
        return acc;
    }, {});
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "p-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                            className: "h-5 w-5 animate-spin"
                        }, void 0, false, {
                            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                            lineNumber: 161,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "Loading documents..."
                        }, void 0, false, {
                            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                            lineNumber: 162,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                    lineNumber: 160,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                lineNumber: 159,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
            lineNumber: 158,
            columnNumber: 13
        }, this);
    }
    if (documents.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "p-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center py-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$folder$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderOpen$3e$__["FolderOpen"], {
                            className: "mx-auto h-12 w-12 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                            lineNumber: 174,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "mt-2 text-sm font-medium text-gray-900",
                            children: "No documents found"
                        }, void 0, false, {
                            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                            lineNumber: 175,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-1 text-sm text-gray-500",
                            children: "This employee hasn't uploaded any documents yet."
                        }, void 0, false, {
                            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                            lineNumber: 176,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                    lineNumber: 173,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                lineNumber: 172,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
            lineNumber: 171,
            columnNumber: 13
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            previewDocument && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(DocumentPreviewModal, {
                document: previewDocument,
                onClose: ()=>setPreviewDocument(null),
                onDownload: handleDownload
            }, void 0, false, {
                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                lineNumber: 189,
                columnNumber: 17
            }, this),
            Object.entries(groupedDocuments).map(([docType, docs])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                                                className: "h-5 w-5"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                lineNumber: 201,
                                                columnNumber: 33
                                            }, this),
                                            DOCUMENT_TYPE_LABELS[docType]
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                        lineNumber: 200,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Badge"], {
                                        variant: "secondary",
                                        children: [
                                            docs.length,
                                            " ",
                                            docs.length === 1 ? 'document' : 'documents'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                        lineNumber: 204,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                lineNumber: 199,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                            lineNumber: 198,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-3",
                                children: docs.map((doc)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-start gap-4 flex-1 min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                                                        className: "h-8 w-8 text-blue-500 flex-shrink-0"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                        lineNumber: 217,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex-1 min-w-0",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-2 flex-wrap",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                        className: "font-medium truncate",
                                                                        children: doc.document_name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                        lineNumber: 220,
                                                                        columnNumber: 49
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Badge"], {
                                                                        className: DOCUMENT_TYPE_COLORS[doc.document_type],
                                                                        children: doc.document_type
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                        lineNumber: 221,
                                                                        columnNumber: 49
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                lineNumber: 219,
                                                                columnNumber: 45
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-sm text-muted-foreground truncate",
                                                                children: doc.original_filename
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                lineNumber: 225,
                                                                columnNumber: 45
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex flex-wrap items-center gap-4 mt-1 text-xs text-muted-foreground",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "flex items-center gap-1",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                                                className: "h-3 w-3"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                                lineNumber: 228,
                                                                                columnNumber: 53
                                                                            }, this),
                                                                            formatDate(doc.uploaded_at)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                        lineNumber: 227,
                                                                        columnNumber: 49
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: formatFileSize(doc.file_size)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                        lineNumber: 231,
                                                                        columnNumber: 49
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "uppercase",
                                                                        children: doc.mime_type.split('/')[1] || doc.mime_type
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                        lineNumber: 232,
                                                                        columnNumber: 49
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                lineNumber: 226,
                                                                columnNumber: 45
                                                            }, this),
                                                            doc.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-sm text-muted-foreground mt-1 line-clamp-2",
                                                                children: doc.description
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                lineNumber: 235,
                                                                columnNumber: 49
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                        lineNumber: 218,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                lineNumber: 216,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2 ml-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                        variant: "ghost",
                                                        size: "icon",
                                                        onClick: ()=>setPreviewDocument(doc),
                                                        title: "Preview",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                                            className: "h-4 w-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                            lineNumber: 249,
                                                            columnNumber: 45
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                        lineNumber: 243,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                        variant: "ghost",
                                                        size: "icon",
                                                        onClick: ()=>handleDownload(doc),
                                                        title: "Download",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                            className: "h-4 w-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                            lineNumber: 257,
                                                            columnNumber: 45
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                        lineNumber: 251,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialog"], {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogTrigger"], {
                                                                asChild: true,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                                    variant: "ghost",
                                                                    size: "icon",
                                                                    disabled: deletingId === doc._id,
                                                                    title: "Delete",
                                                                    children: deletingId === doc._id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                                        className: "h-4 w-4 animate-spin"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                        lineNumber: 268,
                                                                        columnNumber: 57
                                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                        className: "h-4 w-4"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                        lineNumber: 270,
                                                                        columnNumber: 57
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                    lineNumber: 261,
                                                                    columnNumber: 49
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                lineNumber: 260,
                                                                columnNumber: 45
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogContent"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogHeader"], {
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogTitle"], {
                                                                                className: "flex items-center gap-2",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                                                                                        className: "h-5 w-5 text-destructive"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                                        lineNumber: 277,
                                                                                        columnNumber: 57
                                                                                    }, this),
                                                                                    "Delete Document"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                                lineNumber: 276,
                                                                                columnNumber: 53
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogDescription"], {
                                                                                children: [
                                                                                    "Are you sure you want to delete ",
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                                        children: doc.document_name
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                                        lineNumber: 281,
                                                                                        columnNumber: 89
                                                                                    }, this),
                                                                                    "? This action cannot be undone."
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                                lineNumber: 280,
                                                                                columnNumber: 53
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                        lineNumber: 275,
                                                                        columnNumber: 49
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogFooter"], {
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogCancel"], {
                                                                                children: "Cancel"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                                lineNumber: 286,
                                                                                columnNumber: 53
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogAction"], {
                                                                                onClick: ()=>handleDelete(doc._id),
                                                                                className: "bg-destructive hover:bg-destructive/90",
                                                                                children: "Delete"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                                lineNumber: 287,
                                                                                columnNumber: 53
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                        lineNumber: 285,
                                                                        columnNumber: 49
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                                lineNumber: 274,
                                                                columnNumber: 45
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                        lineNumber: 259,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                                lineNumber: 242,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, doc._id, true, {
                                        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                        lineNumber: 212,
                                        columnNumber: 33
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                                lineNumber: 210,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                            lineNumber: 209,
                            columnNumber: 21
                        }, this)
                    ]
                }, docType, true, {
                    fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
                    lineNumber: 197,
                    columnNumber: 17
                }, this))
        ]
    }, void 0, true, {
        fileName: "[project]/app/(protected)/(admin)/employee-documents/page.tsx",
        lineNumber: 186,
        columnNumber: 9
    }, this);
}
}}),

};

//# sourceMappingURL=_23d1af59._.js.map