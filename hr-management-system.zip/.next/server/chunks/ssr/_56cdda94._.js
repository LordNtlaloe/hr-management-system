module.exports = {

"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f07033d9c73c17a63f43a9cfa5012cb6cfef258c2":"updateEmployee","7f216b9e67a84dc38e0c070d8ac699330adbc59d0d":"getEmployeeById","7f4b7cc6a48ce840cd9bc8a27ccaed90acf597d14b":"deleteEmployee","7f5fa9459441e3aae9593059298f1c5b5414b1e9f7":"getAllEmployees","7f770dd82fdf9e51a871237cb143fee4dba4e671fe":"searchEmployees","7fad7e3c02d3cbfc9b26a7ab8f2a5058c1b554980e":"getEmployees","7fd73fd02f8b69452d3050b76c08df4aa935d6c24d":"getEmployeesByDepartment","7fdc8018093dda758a3e68d2b2400a8ca4a16bded5":"getEmployeesByManager","7fde710e388119484bd4ea52fa7815b4ec0a9d432d":"changeEmployeeStatus","7fe73a856bb5a41421c36b83c716fffe022a846e45":"createEmployee"},"",""] */ __turbopack_context__.s({
    "changeEmployeeStatus": (()=>changeEmployeeStatus),
    "createEmployee": (()=>createEmployee),
    "deleteEmployee": (()=>deleteEmployee),
    "getAllEmployees": (()=>getAllEmployees),
    "getEmployeeById": (()=>getEmployeeById),
    "getEmployees": (()=>getEmployees),
    "getEmployeesByDepartment": (()=>getEmployeesByDepartment),
    "getEmployeesByManager": (()=>getEmployeesByManager),
    "searchEmployees": (()=>searchEmployees),
    "updateEmployee": (()=>updateEmployee)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/cache.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
;
let dbConnection;
let database;
const init = async ()=>{
    try {
        const connection = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["connectToDB"])();
        dbConnection = connection;
        database = await dbConnection?.db("hr_management_db");
    } catch (error) {
        console.error("Database connection failed:", error);
        throw error;
    }
};
const createEmployee = async (employeeData)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const employee = {
            ...employeeData,
            departmentId: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeData.departmentId),
            positionId: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeData.positionId),
            managerId: employeeData.managerId ? new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](employeeData.managerId) : null,
            hireDate: new Date(employeeData.hireDate),
            status: 'active',
            createdAt: new Date(),
            updatedAt: new Date()
        };
        const result = await collection.insertOne(employee);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])('/employees');
        return {
            insertedId: result.insertedId,
            success: true
        };
    } catch (error) {
        console.error("Error creating employee:", error.message);
        return {
            error: error.message
        };
    }
};
const getEmployees = async (filters)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const { search = '', department, status, page = 1, limit = 10 } = filters;
        const query = {};
        if (search) {
            query.$or = [
                {
                    firstName: {
                        $regex: search,
                        $options: 'i'
                    }
                },
                {
                    lastName: {
                        $regex: search,
                        $options: 'i'
                    }
                },
                {
                    email: {
                        $regex: search,
                        $options: 'i'
                    }
                },
                {
                    employeeId: {
                        $regex: search,
                        $options: 'i'
                    }
                }
            ];
        }
        if (department) {
            query.departmentId = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](department);
        }
        if (status) {
            query.status = status;
        }
        const skip = (page - 1) * limit;
        const employees = await collection.find(query).skip(skip).limit(limit).toArray();
        const total = await collection.countDocuments(query);
        return {
            employees,
            total,
            page,
            pages: Math.ceil(total / limit)
        };
    } catch (error) {
        console.error("Error fetching employees:", error.message);
        return {
            error: error.message
        };
    }
};
const updateEmployee = async (id, updateData)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        // Convert string IDs to ObjectId if present
        const dataToUpdate = {
            ...updateData
        };
        if (updateData.departmentId) dataToUpdate.departmentId = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](updateData.departmentId);
        if (updateData.positionId) dataToUpdate.positionId = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](updateData.positionId);
        if (updateData.managerId) dataToUpdate.managerId = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](updateData.managerId);
        if (updateData.hireDate) dataToUpdate.hireDate = new Date(updateData.hireDate);
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                ...dataToUpdate,
                updatedAt: new Date()
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])('/employees');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/employees/${id}`);
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error updating employee:", error.message);
        return {
            error: error.message
        };
    }
};
const deleteEmployee = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        // Soft delete - mark as inactive instead of removing
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                isActive: false,
                deletedAt: new Date()
            }
        });
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error deleting employee:", error.message);
        return {
            error: error.message
        };
    }
};
const getAllEmployees = async (params)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const query = {
            isActive: {
                $ne: false
            }
        };
        if (params.search) {
            query.$or = [
                {
                    firstName: {
                        $regex: params.search,
                        $options: 'i'
                    }
                },
                {
                    lastName: {
                        $regex: params.search,
                        $options: 'i'
                    }
                },
                {
                    email: {
                        $regex: params.search,
                        $options: 'i'
                    }
                },
                {
                    employeeId: {
                        $regex: params.search,
                        $options: 'i'
                    }
                }
            ];
        }
        if (params.department) {
            query.departmentId = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](params.department);
        }
        if (params.status) {
            query.status = params.status;
        }
        const skip = (params.page - 1) * params.limit;
        const employees = await collection.find(query).skip(skip).limit(params.limit).toArray();
        const total = await collection.countDocuments(query);
        return {
            employees,
            total,
            page: params.page,
            pages: Math.ceil(total / params.limit)
        };
    } catch (error) {
        console.error("Error fetching employees:", error.message);
        return {
            error: error.message
        };
    }
};
const getEmployeesByDepartment = async (departmentId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        return await collection.find({
            departmentId: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](departmentId),
            isActive: {
                $ne: false
            }
        }).toArray();
    } catch (error) {
        console.error("Error fetching employees by department:", error.message);
        return {
            error: error.message
        };
    }
};
const getEmployeesByManager = async (managerId)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        return await collection.find({
            managerId: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](managerId),
            isActive: {
                $ne: false
            }
        }).toArray();
    } catch (error) {
        console.error("Error fetching employees by manager:", error.message);
        return {
            error: error.message
        };
    }
};
const searchEmployees = async (searchTerm)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        return await collection.find({
            $and: [
                {
                    isActive: {
                        $ne: false
                    }
                },
                {
                    $or: [
                        {
                            firstName: {
                                $regex: searchTerm,
                                $options: 'i'
                            }
                        },
                        {
                            lastName: {
                                $regex: searchTerm,
                                $options: 'i'
                            }
                        },
                        {
                            email: {
                                $regex: searchTerm,
                                $options: 'i'
                            }
                        },
                        {
                            employeeId: {
                                $regex: searchTerm,
                                $options: 'i'
                            }
                        }
                    ]
                }
            ]
        }).toArray();
    } catch (error) {
        console.error("Error searching employees:", error.message);
        return {
            error: error.message
        };
    }
};
const getEmployeeById = async (id)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const employee = await collection.findOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        });
        // Populate department and position data
        const [department, position] = await Promise.all([
            database.collection("departments").findOne({
                _id: employee.departmentId
            }),
            database.collection("positions").findOne({
                _id: employee.positionId
            })
        ]);
        return {
            ...employee,
            department,
            position
        };
    } catch (error) {
        console.error("Error fetching employee:", error.message);
        return {
            error: error.message
        };
    }
};
const changeEmployeeStatus = async (id, status)=>{
    if (!dbConnection) await init();
    try {
        const collection = await database?.collection("employees");
        const result = await collection.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: {
                status,
                updatedAt: new Date()
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])('/employees');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/employees/${id}`);
        return {
            modifiedCount: result.modifiedCount,
            success: true
        };
    } catch (error) {
        console.error("Error changing employee status:", error.message);
        return {
            error: error.message
        };
    }
};
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    createEmployee,
    getEmployees,
    updateEmployee,
    deleteEmployee,
    getAllEmployees,
    getEmployeesByDepartment,
    getEmployeesByManager,
    searchEmployees,
    getEmployeeById,
    changeEmployeeStatus
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createEmployee, "7fe73a856bb5a41421c36b83c716fffe022a846e45", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployees, "7fad7e3c02d3cbfc9b26a7ab8f2a5058c1b554980e", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(updateEmployee, "7f07033d9c73c17a63f43a9cfa5012cb6cfef258c2", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deleteEmployee, "7f4b7cc6a48ce840cd9bc8a27ccaed90acf597d14b", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getAllEmployees, "7f5fa9459441e3aae9593059298f1c5b5414b1e9f7", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeesByDepartment, "7fd73fd02f8b69452d3050b76c08df4aa935d6c24d", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeesByManager, "7fdc8018093dda758a3e68d2b2400a8ca4a16bded5", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(searchEmployees, "7f770dd82fdf9e51a871237cb143fee4dba4e671fe", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getEmployeeById, "7f216b9e67a84dc38e0c070d8ac699330adbc59d0d", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(changeEmployeeStatus, "7fde710e388119484bd4ea52fa7815b4ec0a9d432d", null);
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employees/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.actions.ts [app-rsc] (ecmascript)");
;
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employees/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employees/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employees/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <exports>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "7fe73a856bb5a41421c36b83c716fffe022a846e45": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createEmployee"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/actions/employee.actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employees/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(protected)/(admin)/employees/create/page/actions.js { ACTIONS_MODULE0 => \"[project]/actions/employee.actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "7fe73a856bb5a41421c36b83c716fffe022a846e45": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["7fe73a856bb5a41421c36b83c716fffe022a846e45"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employees/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <module evaluation>');
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$protected$292f28$admin$292f$employees$2f$create$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$actions$2f$employee$2e$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(protected)/(admin)/employees/create/page/actions.js { ACTIONS_MODULE0 => "[project]/actions/employee.actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <exports>');
}}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/(admin)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/(admin)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/(protected)/(admin)/employees/create/page.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/app/(protected)/(admin)/employees/create/page.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/(protected)/(admin)/employees/create/page.tsx <module evaluation>", "default");
}}),
"[project]/app/(protected)/(admin)/employees/create/page.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/app/(protected)/(admin)/employees/create/page.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/(protected)/(admin)/employees/create/page.tsx", "default");
}}),
"[project]/app/(protected)/(admin)/employees/create/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employees$2f$create$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/app/(protected)/(admin)/employees/create/page.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employees$2f$create$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/app/(protected)/(admin)/employees/create/page.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$protected$292f28$admin$292f$employees$2f$create$2f$page$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/app/(protected)/(admin)/employees/create/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/(protected)/(admin)/employees/create/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_56cdda94._.js.map