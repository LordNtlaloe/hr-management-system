module.exports = {

"[project]/actions/data:04153a [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f5fa9459441e3aae9593059298f1c5b5414b1e9f7":"getAllEmployees"},"actions/employee.actions.ts",""] */ __turbopack_context__.s({
    "getAllEmployees": (()=>getAllEmployees)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getAllEmployees = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("7f5fa9459441e3aae9593059298f1c5b5414b1e9f7", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getAllEmployees"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZW1wbG95ZWUuYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIlxuXG5pbXBvcnQgeyBjb25uZWN0VG9EQiB9IGZyb20gXCJAL2xpYi9kYlwiO1xuaW1wb3J0IHsgT2JqZWN0SWQgfSBmcm9tIFwibW9uZ29kYlwiO1xuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tIFwibmV4dC9jYWNoZVwiO1xuXG5cbmxldCBkYkNvbm5lY3Rpb246IGFueTtcbmxldCBkYXRhYmFzZTogYW55O1xuXG5pbnRlcmZhY2UgRW1wbG95ZWUge1xuICBfaWQ/OiBPYmplY3RJZDtcbiAgZW1wbG95ZWVJZDogc3RyaW5nO1xuICBmaXJzdE5hbWU6IHN0cmluZztcbiAgbGFzdE5hbWU6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbiAgcGhvbmU6IHN0cmluZztcbiAgZGVwYXJ0bWVudElkOiBPYmplY3RJZCB8IHN0cmluZztcbiAgcG9zaXRpb25JZDogT2JqZWN0SWQgfCBzdHJpbmc7XG4gIG1hbmFnZXJJZD86IE9iamVjdElkIHwgc3RyaW5nO1xuICBoaXJlRGF0ZTogRGF0ZSB8IHN0cmluZztcbiAgc2FsYXJ5OiBudW1iZXI7XG4gIHN0YXR1czogJ2FjdGl2ZScgfCAnb24tbGVhdmUnIHwgJ3Rlcm1pbmF0ZWQnO1xuICBza2lsbHM/OiBzdHJpbmdbXTtcbiAgY3JlYXRlZEF0PzogRGF0ZTtcbiAgdXBkYXRlZEF0PzogRGF0ZTtcbn1cblxuY29uc3QgaW5pdCA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb25uZWN0aW9uID0gYXdhaXQgY29ubmVjdFRvREIoKTtcbiAgICAgICAgZGJDb25uZWN0aW9uID0gY29ubmVjdGlvbjtcbiAgICAgICAgZGF0YWJhc2UgPSBhd2FpdCBkYkNvbm5lY3Rpb24/LmRiKFwiaHJfbWFuYWdlbWVudF9kYlwiKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgY29ubmVjdGlvbiBmYWlsZWQ6XCIsIGVycm9yKTtcbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxufVxuXG4vLyBFbXBsb3llZSBDUlVEIE9wZXJhdGlvbnNcbmV4cG9ydCBjb25zdCBjcmVhdGVFbXBsb3llZSA9IGFzeW5jIChlbXBsb3llZURhdGE6IE9taXQ8RW1wbG95ZWUsICdfaWQnPikgPT4ge1xuICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICB0cnkge1xuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlc1wiKTtcbiAgICBjb25zdCBlbXBsb3llZSA9IHtcbiAgICAgIC4uLmVtcGxveWVlRGF0YSxcbiAgICAgIGRlcGFydG1lbnRJZDogbmV3IE9iamVjdElkKGVtcGxveWVlRGF0YS5kZXBhcnRtZW50SWQpLFxuICAgICAgcG9zaXRpb25JZDogbmV3IE9iamVjdElkKGVtcGxveWVlRGF0YS5wb3NpdGlvbklkKSxcbiAgICAgIG1hbmFnZXJJZDogZW1wbG95ZWVEYXRhLm1hbmFnZXJJZCA/IG5ldyBPYmplY3RJZChlbXBsb3llZURhdGEubWFuYWdlcklkKSA6IG51bGwsXG4gICAgICBoaXJlRGF0ZTogbmV3IERhdGUoZW1wbG95ZWVEYXRhLmhpcmVEYXRlKSxcbiAgICAgIHN0YXR1czogJ2FjdGl2ZScsXG4gICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICB1cGRhdGVkQXQ6IG5ldyBEYXRlKClcbiAgICB9O1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNvbGxlY3Rpb24uaW5zZXJ0T25lKGVtcGxveWVlKTtcbiAgICByZXZhbGlkYXRlUGF0aCgnL2VtcGxveWVlcycpO1xuICAgIHJldHVybiB7IGluc2VydGVkSWQ6IHJlc3VsdC5pbnNlcnRlZElkLCBzdWNjZXNzOiB0cnVlIH07XG4gIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY3JlYXRpbmcgZW1wbG95ZWU6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gIH1cbn1cblxuXG5leHBvcnQgY29uc3QgZ2V0RW1wbG95ZWVzID0gYXN5bmMgKGZpbHRlcnM6IHtcbiAgc2VhcmNoPzogc3RyaW5nO1xuICBkZXBhcnRtZW50Pzogc3RyaW5nO1xuICBzdGF0dXM/OiBzdHJpbmc7XG4gIHBhZ2U/OiBudW1iZXI7XG4gIGxpbWl0PzogbnVtYmVyO1xufSkgPT4ge1xuICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICB0cnkge1xuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlc1wiKTtcbiAgICBjb25zdCB7IHNlYXJjaCA9ICcnLCBkZXBhcnRtZW50LCBzdGF0dXMsIHBhZ2UgPSAxLCBsaW1pdCA9IDEwIH0gPSBmaWx0ZXJzO1xuICAgIFxuICAgIGNvbnN0IHF1ZXJ5OiBhbnkgPSB7fTtcbiAgICBcbiAgICBpZiAoc2VhcmNoKSB7XG4gICAgICBxdWVyeS4kb3IgPSBbXG4gICAgICAgIHsgZmlyc3ROYW1lOiB7ICRyZWdleDogc2VhcmNoLCAkb3B0aW9uczogJ2knIH0gfSxcbiAgICAgICAgeyBsYXN0TmFtZTogeyAkcmVnZXg6IHNlYXJjaCwgJG9wdGlvbnM6ICdpJyB9IH0sXG4gICAgICAgIHsgZW1haWw6IHsgJHJlZ2V4OiBzZWFyY2gsICRvcHRpb25zOiAnaScgfSB9LFxuICAgICAgICB7IGVtcGxveWVlSWQ6IHsgJHJlZ2V4OiBzZWFyY2gsICRvcHRpb25zOiAnaScgfSB9XG4gICAgICBdO1xuICAgIH1cbiAgICBcbiAgICBpZiAoZGVwYXJ0bWVudCkge1xuICAgICAgcXVlcnkuZGVwYXJ0bWVudElkID0gbmV3IE9iamVjdElkKGRlcGFydG1lbnQpO1xuICAgIH1cbiAgICBcbiAgICBpZiAoc3RhdHVzKSB7XG4gICAgICBxdWVyeS5zdGF0dXMgPSBzdGF0dXM7XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHNraXAgPSAocGFnZSAtIDEpICogbGltaXQ7XG4gICAgY29uc3QgZW1wbG95ZWVzID0gYXdhaXQgY29sbGVjdGlvbi5maW5kKHF1ZXJ5KVxuICAgICAgLnNraXAoc2tpcClcbiAgICAgIC5saW1pdChsaW1pdClcbiAgICAgIC50b0FycmF5KCk7XG4gICAgICBcbiAgICBjb25zdCB0b3RhbCA9IGF3YWl0IGNvbGxlY3Rpb24uY291bnREb2N1bWVudHMocXVlcnkpO1xuICAgIFxuICAgIHJldHVybiB7XG4gICAgICBlbXBsb3llZXMsXG4gICAgICB0b3RhbCxcbiAgICAgIHBhZ2UsXG4gICAgICBwYWdlczogTWF0aC5jZWlsKHRvdGFsIC8gbGltaXQpXG4gICAgfTtcbiAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZXM6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IHVwZGF0ZUVtcGxveWVlID0gYXN5bmMgKGlkOiBzdHJpbmcsIHVwZGF0ZURhdGE6IFBhcnRpYWw8RW1wbG95ZWU+KSA9PiB7XG4gIGlmICghZGJDb25uZWN0aW9uKSBhd2FpdCBpbml0KCk7XG4gIHRyeSB7XG4gICAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGRhdGFiYXNlPy5jb2xsZWN0aW9uKFwiZW1wbG95ZWVzXCIpO1xuICAgIFxuICAgIC8vIENvbnZlcnQgc3RyaW5nIElEcyB0byBPYmplY3RJZCBpZiBwcmVzZW50XG4gICAgY29uc3QgZGF0YVRvVXBkYXRlOiBhbnkgPSB7IC4uLnVwZGF0ZURhdGEgfTtcbiAgICBpZiAodXBkYXRlRGF0YS5kZXBhcnRtZW50SWQpIGRhdGFUb1VwZGF0ZS5kZXBhcnRtZW50SWQgPSBuZXcgT2JqZWN0SWQodXBkYXRlRGF0YS5kZXBhcnRtZW50SWQpO1xuICAgIGlmICh1cGRhdGVEYXRhLnBvc2l0aW9uSWQpIGRhdGFUb1VwZGF0ZS5wb3NpdGlvbklkID0gbmV3IE9iamVjdElkKHVwZGF0ZURhdGEucG9zaXRpb25JZCk7XG4gICAgaWYgKHVwZGF0ZURhdGEubWFuYWdlcklkKSBkYXRhVG9VcGRhdGUubWFuYWdlcklkID0gbmV3IE9iamVjdElkKHVwZGF0ZURhdGEubWFuYWdlcklkKTtcbiAgICBpZiAodXBkYXRlRGF0YS5oaXJlRGF0ZSkgZGF0YVRvVXBkYXRlLmhpcmVEYXRlID0gbmV3IERhdGUodXBkYXRlRGF0YS5oaXJlRGF0ZSk7XG4gICAgXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi51cGRhdGVPbmUoXG4gICAgICB7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9LFxuICAgICAgeyAkc2V0OiB7IC4uLmRhdGFUb1VwZGF0ZSwgdXBkYXRlZEF0OiBuZXcgRGF0ZSgpIH0gfVxuICAgICk7XG4gICAgXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9lbXBsb3llZXMnKTtcbiAgICByZXZhbGlkYXRlUGF0aChgL2VtcGxveWVlcy8ke2lkfWApO1xuICAgIHJldHVybiB7IG1vZGlmaWVkQ291bnQ6IHJlc3VsdC5tb2RpZmllZENvdW50LCBzdWNjZXNzOiB0cnVlIH07XG4gIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZW1wbG95ZWU6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGRlbGV0ZUVtcGxveWVlID0gYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlc1wiKTtcbiAgICAgICAgLy8gU29mdCBkZWxldGUgLSBtYXJrIGFzIGluYWN0aXZlIGluc3RlYWQgb2YgcmVtb3ZpbmdcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi51cGRhdGVPbmUoXG4gICAgICAgICAgICB7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9LFxuICAgICAgICAgICAgeyAkc2V0OiB7IGlzQWN0aXZlOiBmYWxzZSwgZGVsZXRlZEF0OiBuZXcgRGF0ZSgpIH0gfVxuICAgICAgICApO1xuICAgICAgICByZXR1cm4geyBtb2RpZmllZENvdW50OiByZXN1bHQubW9kaWZpZWRDb3VudCwgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGVtcGxveWVlOlwiLCBlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfTtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBnZXRBbGxFbXBsb3llZXMgPSBhc3luYyAoaW5jbHVkZUluYWN0aXZlID0gZmFsc2UpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlc1wiKTtcbiAgICAgICAgY29uc3QgZmlsdGVyID0gaW5jbHVkZUluYWN0aXZlID8ge30gOiB7IGlzQWN0aXZlOiB7ICRuZTogZmFsc2UgfSB9O1xuICAgICAgICByZXR1cm4gYXdhaXQgY29sbGVjdGlvbi5maW5kKGZpbHRlcikudG9BcnJheSgpO1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlczpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZ2V0RW1wbG95ZWVzQnlEZXBhcnRtZW50ID0gYXN5bmMgKGRlcGFydG1lbnRJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFkYkNvbm5lY3Rpb24pIGF3YWl0IGluaXQoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gYXdhaXQgZGF0YWJhc2U/LmNvbGxlY3Rpb24oXCJlbXBsb3llZXNcIik7XG4gICAgICAgIHJldHVybiBhd2FpdCBjb2xsZWN0aW9uLmZpbmQoeyBcbiAgICAgICAgICAgIGRlcGFydG1lbnRJZDogbmV3IE9iamVjdElkKGRlcGFydG1lbnRJZCksXG4gICAgICAgICAgICBpc0FjdGl2ZTogeyAkbmU6IGZhbHNlIH1cbiAgICAgICAgfSkudG9BcnJheSgpO1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlcyBieSBkZXBhcnRtZW50OlwiLCBlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfTtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBnZXRFbXBsb3llZXNCeU1hbmFnZXIgPSBhc3luYyAobWFuYWdlcklkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlc1wiKTtcbiAgICAgICAgcmV0dXJuIGF3YWl0IGNvbGxlY3Rpb24uZmluZCh7IFxuICAgICAgICAgICAgbWFuYWdlcklkOiBuZXcgT2JqZWN0SWQobWFuYWdlcklkKSxcbiAgICAgICAgICAgIGlzQWN0aXZlOiB7ICRuZTogZmFsc2UgfVxuICAgICAgICB9KS50b0FycmF5KCk7XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWVzIGJ5IG1hbmFnZXI6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IHNlYXJjaEVtcGxveWVlcyA9IGFzeW5jIChzZWFyY2hUZXJtOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlc1wiKTtcbiAgICAgICAgcmV0dXJuIGF3YWl0IGNvbGxlY3Rpb24uZmluZCh7XG4gICAgICAgICAgICAkYW5kOiBbXG4gICAgICAgICAgICAgICAgeyBpc0FjdGl2ZTogeyAkbmU6IGZhbHNlIH0gfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICRvcjogW1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBmaXJzdE5hbWU6IHsgJHJlZ2V4OiBzZWFyY2hUZXJtLCAkb3B0aW9uczogJ2knIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFzdE5hbWU6IHsgJHJlZ2V4OiBzZWFyY2hUZXJtLCAkb3B0aW9uczogJ2knIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgZW1haWw6IHsgJHJlZ2V4OiBzZWFyY2hUZXJtLCAkb3B0aW9uczogJ2knIH0gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgZW1wbG95ZWVJZDogeyAkcmVnZXg6IHNlYXJjaFRlcm0sICRvcHRpb25zOiAnaScgfSB9XG4gICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH0pLnRvQXJyYXkoKTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBzZWFyY2hpbmcgZW1wbG95ZWVzOlwiLCBlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfTtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBnZXRFbXBsb3llZUJ5SWQgPSBhc3luYyAoaWQ6IHN0cmluZykgPT4ge1xuICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICB0cnkge1xuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlc1wiKTtcbiAgICBjb25zdCBlbXBsb3llZSA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZE9uZSh7IF9pZDogbmV3IE9iamVjdElkKGlkKSB9KTtcbiAgICBcbiAgICAvLyBQb3B1bGF0ZSBkZXBhcnRtZW50IGFuZCBwb3NpdGlvbiBkYXRhXG4gICAgY29uc3QgW2RlcGFydG1lbnQsIHBvc2l0aW9uXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIGRhdGFiYXNlLmNvbGxlY3Rpb24oXCJkZXBhcnRtZW50c1wiKS5maW5kT25lKHsgX2lkOiBlbXBsb3llZS5kZXBhcnRtZW50SWQgfSksXG4gICAgICBkYXRhYmFzZS5jb2xsZWN0aW9uKFwicG9zaXRpb25zXCIpLmZpbmRPbmUoeyBfaWQ6IGVtcGxveWVlLnBvc2l0aW9uSWQgfSlcbiAgICBdKTtcbiAgICBcbiAgICByZXR1cm4ge1xuICAgICAgLi4uZW1wbG95ZWUsXG4gICAgICBkZXBhcnRtZW50LFxuICAgICAgcG9zaXRpb25cbiAgICB9O1xuICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlOlwiLCBlcnJvci5tZXNzYWdlKTtcbiAgICByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9O1xuICB9XG59XG5cbmV4cG9ydCBjb25zdCBjaGFuZ2VFbXBsb3llZVN0YXR1cyA9IGFzeW5jIChpZDogc3RyaW5nLCBzdGF0dXM6ICdhY3RpdmUnIHwgJ29uLWxlYXZlJyB8ICd0ZXJtaW5hdGVkJykgPT4ge1xuICBpZiAoIWRiQ29ubmVjdGlvbikgYXdhaXQgaW5pdCgpO1xuICB0cnkge1xuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBhd2FpdCBkYXRhYmFzZT8uY29sbGVjdGlvbihcImVtcGxveWVlc1wiKTtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjb2xsZWN0aW9uLnVwZGF0ZU9uZShcbiAgICAgIHsgX2lkOiBuZXcgT2JqZWN0SWQoaWQpIH0sXG4gICAgICB7ICRzZXQ6IHsgc3RhdHVzLCB1cGRhdGVkQXQ6IG5ldyBEYXRlKCkgfSB9XG4gICAgKTtcbiAgICBcbiAgICByZXZhbGlkYXRlUGF0aCgnL2VtcGxveWVlcycpO1xuICAgIHJldmFsaWRhdGVQYXRoKGAvZW1wbG95ZWVzLyR7aWR9YCk7XG4gICAgcmV0dXJuIHsgbW9kaWZpZWRDb3VudDogcmVzdWx0Lm1vZGlmaWVkQ291bnQsIHN1Y2Nlc3M6IHRydWUgfTtcbiAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjaGFuZ2luZyBlbXBsb3llZSBzdGF0dXM6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICAgIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH07XG4gIH1cbn0iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Im9TQTZKYSJ9
}}),
"[project]/components/common/PageBreadCrumb.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
;
;
const PageBreadcrumb = ({ pageTitle })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-wrap items-center justify-between gap-3 mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-gray-800 dark:text-white/90",
                "x-text": "pageName",
                children: pageTitle
            }, void 0, false, {
                fileName: "[project]/components/common/PageBreadCrumb.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "flex items-center gap-1.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                className: "inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400",
                                href: "/",
                                children: [
                                    "Home",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "stroke-current",
                                        width: "17",
                                        height: "16",
                                        viewBox: "0 0 17 16",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M6.0765 12.667L10.2432 8.50033L6.0765 4.33366",
                                            stroke: "",
                                            strokeWidth: "1.2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }, void 0, false, {
                                            fileName: "[project]/components/common/PageBreadCrumb.tsx",
                                            lineNumber: 33,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/common/PageBreadCrumb.tsx",
                                        lineNumber: 25,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/common/PageBreadCrumb.tsx",
                                lineNumber: 20,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/common/PageBreadCrumb.tsx",
                            lineNumber: 19,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            className: "text-sm text-gray-800 dark:text-white/90",
                            children: pageTitle
                        }, void 0, false, {
                            fileName: "[project]/components/common/PageBreadCrumb.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/common/PageBreadCrumb.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/common/PageBreadCrumb.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/common/PageBreadCrumb.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = PageBreadcrumb;
}}),
"[project]/lib/utils.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "cn": (()=>cn)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}}),
"[project]/components/ui/button.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Button": (()=>Button),
    "buttonVariants": (()=>buttonVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",
            destructive: "bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/button.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
;
}}),
"[project]/app/(protected)/(admin)/employees/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>EmployeesPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$data$3a$04153a__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/actions/data:04153a [app-ssr] (ecmascript) <text/javascript>");
(()=>{
    const e = new Error("Cannot find module '@/components/dashboard/employees/employees-table'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/components/employees/EmployeeFilters'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$PageBreadCrumb$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/PageBreadCrumb.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function EmployeesPage() {
    const [employees, setEmployees] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [pagination, setPagination] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        page: 1,
        limit: 10,
        total: 0,
        pages: 1
    });
    const [filters, setFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        search: '',
        department: '',
        status: ''
    });
    const fetchEmployees = async ()=>{
        setLoading(true);
        try {
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$data$3a$04153a__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getAllEmployees"])({
                ...filters,
                page: pagination.page,
                limit: pagination.limit
            });
            if (!result.error) {
                setEmployees(result.employees);
                setPagination({
                    ...pagination,
                    total: result.total,
                    pages: result.pages
                });
            }
        } catch (error) {
            console.error('Error fetching employees:', error);
        } finally{
            setLoading(false);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        fetchEmployees();
    }, [
        filters,
        pagination.page
    ]);
    const handlePageChange = (newPage)=>{
        setPagination({
            ...pagination,
            page: newPage
        });
    };
    const handleFilterChange = (newFilters)=>{
        setFilters(newFilters);
        setPagination({
            ...pagination,
            page: 1
        }); // Reset to first page when filters change
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$PageBreadCrumb$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        items: [
                            {
                                label: 'HR',
                                path: '/hr'
                            },
                            {
                                label: 'Employees',
                                path: '/employees'
                            }
                        ]
                    }, void 0, false, {
                        fileName: "[project]/app/(protected)/(admin)/employees/page.tsx",
                        lineNumber: 65,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/employees/add",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                            children: "Add Employee"
                        }, void 0, false, {
                            fileName: "[project]/app/(protected)/(admin)/employees/page.tsx",
                            lineNumber: 72,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(protected)/(admin)/employees/page.tsx",
                        lineNumber: 71,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(protected)/(admin)/employees/page.tsx",
                lineNumber: 64,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(EmployeeFilters, {
                filters: filters,
                onChange: handleFilterChange
            }, void 0, false, {
                fileName: "[project]/app/(protected)/(admin)/employees/page.tsx",
                lineNumber: 76,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(EmployeeTable, {
                employees: employees,
                loading: loading,
                pagination: pagination,
                onPageChange: handlePageChange
            }, void 0, false, {
                fileName: "[project]/app/(protected)/(admin)/employees/page.tsx",
                lineNumber: 81,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(protected)/(admin)/employees/page.tsx",
        lineNumber: 63,
        columnNumber: 9
    }, this);
}
}}),

};

//# sourceMappingURL=_32dc5143._.js.map