import EmployeesTable from '@/components/dashboard/employees/employees-table'
import React from 'react'

export default function Employees() {
    return (
        <div>
            <EmployeesTable />
        </div>
    )
}
