import SignUpForm from '@/components/auth/sign-up-form'
import React from 'react'

export default function page() {
  return (
    <div className="">
      <SignUpForm />
    </div>

  )
}
