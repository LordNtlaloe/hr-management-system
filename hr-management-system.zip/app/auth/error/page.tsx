import React from 'react'
import ErrorCard from '@/components/general/error-card'

export default function ErrorPage() {
  return (
    <ErrorCard />
  )
}
