import React from 'react'
import VerificationForm from '@/components/auth/verification-form'

export default function VerificationEmailPage() {
    return (
        <div>
            <VerificationForm />
        </div>
    )
}
